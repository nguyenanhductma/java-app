package org.example.services;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.repositories.entities.Singer;
import org.example.repositories.interfaces.SingerRepository;
import org.example.repositories.persistences.JPATransactionManager;
import org.example.services.dtos.request.singers.DeleteSingerRequest;
import org.example.services.dtos.request.singers.UpdateSingerRequest;
import org.example.services.dtos.response.singers.GetSingerResponse;
import org.example.services.implementations.SingerServiceImpl;
import org.example.services.interfaces.SingerService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SingerServiceTest {
    @InjectMocks
    private SingerService singerService = new SingerServiceImpl();

    @Mock
    private SingerRepository singerRepository;

    @Mock
    private EntityManager entityManager;

    @Mock
    private TypedQuery<Singer> singerQuery;

    @Mock
    private JPATransactionManager transactionManager;

    @Test
    public void getSingersShouldBeSuccessful() {
        Singer s1 = new Singer();

        s1.setName("Adele");
        s1.setAge(35);

        Singer s2 = new Singer();

        s2.setName("Ed Sheeran");
        s2.setAge(33);

        when(singerRepository.getEntityManager())
                .thenReturn(entityManager);

        when(entityManager.createQuery(anyString(), eq(Singer.class)))
                .thenReturn(singerQuery);

        when(singerQuery.getResultList())
                .thenReturn(List.of(s1, s2));

        List<GetSingerResponse> result =
                singerService.getSingers();

        assertEquals(2, result.size());

        GetSingerResponse dto1 = result.get(0);

        assertEquals("Adele", dto1.name);
        assertEquals(35, dto1.age);

        GetSingerResponse dto2 = result.get(1);
        assertEquals("Ed Sheeran", dto2.name);
        assertEquals(33, dto2.age);

        verify(singerRepository).getEntityManager();
        verify(singerQuery).getResultList();
    }

    @Test
    public void deleteSingerShouldBeSuccessful() {
        Singer singer = new Singer();

        singer.setId(UUID.randomUUID());
        singer.setName("Alice");
        singer.setAge(50);

        when(singerRepository.getTransactionManager())
                .thenReturn(transactionManager);

        doAnswer(invocationOnMock -> {
            Runnable r = invocationOnMock.getArgument(0);

            r.run();

            return null;
        }).when(transactionManager).runInTransaction(any(Runnable.class));

        when(singerRepository.find("id", singer.getId(), false))
                .thenReturn(Optional.of(singer));

        singerService.deleteSinger(new DeleteSingerRequest(singer.getId()));

        verify(singerRepository).find("id", singer.getId(), false);
        verify(singerRepository).delete(singer);
    }

    @Test
    public void deleteSigner_shouldThrowNotFoundWhenNotExistedSinger() {
        Singer singer = new Singer();

        singer.setId(UUID.randomUUID());

        when(singerRepository.find("id", singer.getId(), false))
                .thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(
                RuntimeException.class,
                () -> singerService.deleteSinger(new DeleteSingerRequest(
                        singer.getId()
                ))
        );

        assertEquals("Singer not found", ex.getMessage());
    }

    @Test
    public void updateSingerShouldBeSuccessful() {
        Singer existed = new Singer();

        UUID id = UUID.randomUUID();

        existed.setId(id);
        existed.setAge(50);
        existed.setName("Alice");

        Singer updateSinger = new Singer();

        updateSinger.setId(id);
        updateSinger.setName("In Wonderland");
        updateSinger.setAge(4);

        when(singerRepository.getTransactionManager())
                .thenReturn(transactionManager);

        doAnswer(invocationOnMock -> {
            Runnable r = invocationOnMock.getArgument(0);

            r.run();

            return null;
        }).when(transactionManager).runInTransaction(any(Runnable.class));

        when(singerRepository.find("id", id, false))
                .thenReturn(Optional.of(existed));

        singerService.updateSinger(new UpdateSingerRequest(
                updateSinger.getId(),
                updateSinger.getName(),
                updateSinger.getAge())
        );

        verify(singerRepository).find("id", id, false);
        verify(singerRepository).update(existed);

        assertEquals("In Wonderland", existed.getName());
        assertEquals(4, existed.getAge());
    }

    @Test
    public void updateSinger_shouldThrowNotFoundWhenNotExistedSinger() {
        Singer singer = new Singer();

        singer.setId(UUID.randomUUID());

        when(singerRepository.find("id", singer.getId(), false))
                .thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> singerService.updateSinger(new UpdateSingerRequest(
                singer.getId()
        )));

        assertEquals("Singer not found", ex.getMessage());
    }

    @Test
    public void createSingerShouldBeSuccessful() {
        Singer singer = new Singer();

        singer.setName("Exodia");
        singer.setAge(45);

        ArgumentCaptor<Singer> captor = ArgumentCaptor.forClass(Singer.class);

        when(singerRepository.getTransactionManager())
                .thenReturn(transactionManager);

        doAnswer(invocationOnMock -> {
            Runnable r = invocationOnMock.getArgument(0);

            r.run();

            return null;
        }).when(transactionManager).runInTransaction(any(Runnable.class));

        singerService.createNewSinger(
                singer.getName(),
                singer.getAge()
        );

        verify(singerRepository).insert(captor.capture());

        Singer saved = captor.getValue();

        assertEquals("Exodia", saved.getName());
        assertEquals(45, saved.getAge());
    }

    @Test
    public void findSingerById_shouldReturnExistedSinger() {
        UUID id = UUID.randomUUID();

        Singer singer = new Singer();

        singer.setId(id);
        singer.setName("T-Hex");
        singer.setAge(102560);

        when(singerRepository.find("id", id, false))
                .thenReturn(Optional.of(singer));

        GetSingerResponse result = singerService.getSinger(id);

        assertEquals("T-Hex", result.name);
        assertEquals(102560, result.age);
    }

    @Test
    public void findSingerById_shouldThrowNotFoundWhenNotExistedSigner() {
        UUID id = UUID.randomUUID();

        when(singerRepository.find("id", id, false))
                .thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(
                RuntimeException.class,
                () -> singerService.getSinger(id)
        );

        assertEquals("Singer not found", ex.getMessage());
    }
}
