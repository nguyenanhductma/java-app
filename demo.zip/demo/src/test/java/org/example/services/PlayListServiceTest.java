package org.example.services;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.controllers.annotations.helpers.FileUpload;
import org.example.repositories.entities.EntityBase;
import org.example.repositories.entities.Music;
import org.example.repositories.entities.PlayList;
import org.example.repositories.entities.Singer;
import org.example.repositories.interfaces.MusicRepository;
import org.example.repositories.interfaces.PlayListRepository;
import org.example.repositories.interfaces.SingerRepository;
import org.example.repositories.persistences.JPATransactionManager;
import org.example.services.dtos.request.playlists.CreateNewPlayListRequest;
import org.example.services.dtos.request.playlists.DeletePlayListRequest;
import org.example.services.dtos.request.playlists.GetPlayListsRequest;
import org.example.services.dtos.request.playlists.UpdatePlayListRequest;
import org.example.services.dtos.response.PaginationResponse;
import org.example.services.dtos.response.playlists.GetPlayListResponse;
import org.example.services.helpers.FileHelper;
import org.example.services.implementations.PlayListServiceImpl;
import org.example.services.interfaces.PlayListService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import java.nio.file.Path;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PlayListServiceTest {
    @Mock
    private PlayListRepository playListRepository;

    @Mock
    private SingerRepository singerRepository;

    @Mock
    private MusicRepository musicRepository;

    @Mock
    private EntityManager entityManager;

    @Mock
    private JPATransactionManager transactionManager;

    @Mock
    private TypedQuery<PlayList> playListQuery;

    @Mock
    private TypedQuery<Long> countQuery;

    @InjectMocks
    private PlayListService playListService = new PlayListServiceImpl();

    @Test
    public void createNewPlayList_withMultipleMusicsAttached_shouldReturnSuccessful() {
        Singer singer = new Singer();

        singer.setName("VI");
        singer.setAge(25);

        Music existedFirstMusic = new Music(
                UUID.randomUUID(),
                new Date(),
                "spring",
                "new Spring",
                132,
                singer
        );

        Music existedSecondMusic = new Music(
                UUID.randomUUID(),
                new Date(),
                "fall",
                "new fall",
                530,
                singer
        );

        Music notExistedMusic = new Music(
                UUID.randomUUID(),
                new Date(),
                "sky",
                "no Sky fall",
                5300,
                singer
        );

        PlayList playList = new PlayList();

        playList.setName("spring");
        playList.setDescription("new spring");
        playList.setSinger(singer);
        playList.setMusics(List.of(existedFirstMusic, existedSecondMusic, notExistedMusic));

        FileUpload fileUpload = new FileUpload(
                "cover.png",
                new byte[]{1, 2, 3}
        );

        ArgumentCaptor<PlayList> playListCaptor = ArgumentCaptor.forClass(PlayList.class);
        ArgumentCaptor<Music> musicCaptor = ArgumentCaptor.forClass(Music.class);

        when(playListRepository.getTransactionManager())
                .thenReturn(transactionManager);

        doAnswer(invocationOnMock -> {
            Runnable r = invocationOnMock.getArgument(0);

            r.run();

            return null;
        }).when(transactionManager).runInTransaction(any(Runnable.class));

        when(singerRepository.find("id", singer.getId(), false))
                .thenReturn(Optional.of(singer));

        when(musicRepository.find("id", existedFirstMusic.getId(), false))
                .thenReturn(Optional.of(existedFirstMusic));

        when(musicRepository.find("id", existedSecondMusic.getId(), false))
                .thenReturn(Optional.of(existedSecondMusic));

        when(musicRepository.find("id", notExistedMusic.getId(), false))
                .thenReturn(Optional.of(notExistedMusic));

        try (MockedStatic<FileHelper> mocked = mockStatic(FileHelper.class)) {
            mocked.when(() -> FileHelper.saveFile(any()))
                    .thenReturn(Path.of("image.png"));

            playListService.createNewPlayList(new CreateNewPlayListRequest(
                    playList.getName(),
                    playList.getDescription(),
                    playList.getSinger().getId(),
                    playList.getMusics().stream().map(EntityBase::getId).toList()
            ), fileUpload);
        }

        verify(playListRepository).insert(playListCaptor.capture());
        verify(musicRepository, times(3)).update(musicCaptor.capture());

        PlayList saved = playListCaptor.getValue();
        List<Music> capturedMusics = musicCaptor.getAllValues();

        assertEquals(playList.getName(), saved.getName());
        assertEquals(playList.getDescription(), saved.getDescription());
        assertEquals(playList.getSinger().getId(), saved.getSinger().getId());
        assertTrue(
                capturedMusics.stream()
                        .allMatch(m -> m.getPlayList().equals(saved))
        );
    }

    @Test
    public void createNewPlayList_withSingerNotFound_shouldThrowSingerNotFoundException() {
        Singer singer = new Singer();
        singer.setId(UUID.randomUUID());

        when(singerRepository.find("id", singer.getId(), false))
                .thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> playListService.createNewPlayList(
                new CreateNewPlayListRequest(
                        "Summer vibe",
                        "The unwind and chilling summer",
                        singer.getId(),
                        List.of(UUID.randomUUID(), UUID.randomUUID())
                ), null
        ));

        assertEquals("Singer not found", ex.getMessage());
    }

    @Test
    public void getPlayList_withPagination_shouldReturnSuccessful() {
        GetPlayListsRequest request = new GetPlayListsRequest();
        request.page = 1;
        request.pageSize = 10;
        request.name = "spring";

        Singer singer = new Singer();
        singer.setId(UUID.randomUUID());

        PlayList p1 = new PlayList();
        p1.setId(UUID.randomUUID());
        p1.setName("Spring Hits");
        p1.setDescription("Desc 1");
        p1.setImageUrl("img1.png");
        p1.setSinger(singer);

        PlayList p2 = new PlayList();
        p2.setId(UUID.randomUUID());
        p2.setName("Spring Chill");
        p2.setDescription("Desc 2");
        p2.setImageUrl("img2.png");
        p2.setSinger(singer);

        List<PlayList> playLists = List.of(p1, p2);

        when(playListRepository.getEntityManager())
                .thenReturn(entityManager);

        when(entityManager.createQuery(anyString(), eq(PlayList.class)))
                .thenReturn(playListQuery);

        when(playListQuery.setFirstResult(anyInt()))
                .thenReturn(playListQuery);

        when(playListQuery.setMaxResults(anyInt()))
                .thenReturn(playListQuery);

        when(playListQuery.setParameter(eq("name"), any()))
                .thenReturn(playListQuery);

        when(playListQuery.getResultList())
                .thenReturn(playLists);

        when(entityManager.createQuery(anyString(), eq(Long.class)))
                .thenReturn(countQuery);

        when(countQuery.getSingleResult())
                .thenReturn(2L);

        PaginationResponse<GetPlayListResponse> response =
                playListService.getPlayLists(request);

        assertEquals(1, response.page);
        assertEquals(10, response.pageSize);
        assertEquals(1, response.totalPage);
        assertEquals(2, response.totalRecords);
        assertEquals(2, response.currentPageRecords);

        assertEquals(2, response.data.size());

        GetPlayListResponse r1 = response.data.get(0);
        assertEquals(p1.getId(), r1.id);
        assertEquals("Spring Hits", r1.name);
        assertEquals("Desc 1", r1.description);
        assertEquals("img1.png", r1.imageUrl);
        assertEquals(singer.getId(), r1.singerId);
    }

    @Test
    public void deletePlayList_withPlayListIsNull_shouldThrowPlayListNotFoundException() {
        DeletePlayListRequest request = new DeletePlayListRequest();
        request.id = UUID.randomUUID();

        when(playListRepository.find("id", request.id, false))
                .thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> playListService.deletePlayList(request));

        assertEquals("PlayList not found", ex.getMessage());
    }

    @Test
    public void deletePlayList_shouldReturnSuccessful() {
        UUID id = UUID.randomUUID();
        DeletePlayListRequest request = new DeletePlayListRequest();
        request.id = id;

        PlayList playList = new PlayList();

        playList.setId(id);
        playList.setName("Summer vibe");
        playList.setDescription("Wonderful summer vibe at Ohio");

        when(playListRepository.getTransactionManager())
                .thenReturn(transactionManager);

        doAnswer(invocationOnMock -> {
            Runnable r = invocationOnMock.getArgument(0);

            r.run();

            return null;
        }).when(transactionManager).runInTransaction(any(Runnable.class));

        when(playListRepository.find("id", id, false))
                .thenReturn(Optional.of(playList));

        playListService.deletePlayList(request);

        verify(playListRepository).delete(playList);
    }

    @Test
    public void updatePlayList_withNotFoundPlayList_shouldThrowPlayListNotFoundException() {
        UpdatePlayListRequest request = new UpdatePlayListRequest();
        request.id = UUID.randomUUID();

        when(playListRepository.find("id", request.id, false))
                .thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> playListService.updatePlayList(request, null));

        assertEquals("PlayList not found", ex.getMessage());
    }

    @Test
    public void updatePlayList_withNotFoundSinger_shouldThrowSingerNotFoundException() {
        UpdatePlayListRequest request = new UpdatePlayListRequest();
        request.id = UUID.randomUUID();
        request.singerId = UUID.randomUUID();

        PlayList playList = new PlayList();
        playList.setId(request.id);

        when(playListRepository.find("id", request.id, false))
                .thenReturn(Optional.of(playList));

        when(singerRepository.find("id", request.singerId, false))
                .thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> playListService.updatePlayList(request, null));

        assertEquals("Singer not found", ex.getMessage());
    }

    @Test
    void updatePlayList_withoutUploadFile_shouldUpdateSuccessfully() {
        UUID playListId = UUID.randomUUID();
        UUID singerId = UUID.randomUUID();

        UpdatePlayListRequest request = new UpdatePlayListRequest();

        request.id = playListId;
        request.singerId = singerId;
        request.name = "Summer vibe";
        request.description = "A summer vacation";

        PlayList playList = new PlayList();
        playList.setId(playListId);

        Singer singer = new Singer();
        singer.setId(singerId);

        when(playListRepository.find("id", playListId, false))
                .thenReturn(Optional.of(playList));

        when(singerRepository.find("id", singerId, false))
                .thenReturn(Optional.of(singer));

        when(playListRepository.getTransactionManager())
                .thenReturn(transactionManager);

        doAnswer(invocation -> {
            Runnable r = invocation.getArgument(0);
            r.run();
            return null;
        }).when(transactionManager).runInTransaction(any(Runnable.class));

        playListService.updatePlayList(request, null);

        verify(playListRepository).update(playList);

        assertEquals(request.name, playList.getName());
        assertEquals(request.description, playList.getDescription());
        assertEquals(singer, playList.getSinger());
    }

    @Test
    void updatePlayList_shouldUpdateImage_whenFileProvided() {
        UUID playListId = UUID.randomUUID();
        UUID singerId = UUID.randomUUID();

        UpdatePlayListRequest request = new UpdatePlayListRequest();
        request.id = playListId;
        request.singerId = singerId;
        request.name = "Summer vibe";
        request.description = "A summer vacation";

        PlayList playList = new PlayList();
        playList.setId(playListId);

        Singer singer = new Singer();
        singer.setId(singerId);

        FileUpload fileUpload =
                new FileUpload("image.png", new byte[]{1, 2, 3});

        when(playListRepository.find("id", playListId, false))
                .thenReturn(Optional.of(playList));

        when(singerRepository.find("id", singerId, false))
                .thenReturn(Optional.of(singer));

        when(playListRepository.getTransactionManager())
                .thenReturn(transactionManager);

        doAnswer(invocation -> {
            Runnable r = invocation.getArgument(0);
            r.run();
            return null;
        }).when(transactionManager).runInTransaction(any());

        try (MockedStatic<FileHelper> mocked = mockStatic(FileHelper.class)) {
            mocked.when(() -> FileHelper.saveFile(fileUpload))
                    .thenReturn(Path.of("image.png"));

            playListService.updatePlayList(request, fileUpload);
        }

        verify(playListRepository).update(playList);
        assertEquals("image.png", playList.getImageUrl());
    }
}
