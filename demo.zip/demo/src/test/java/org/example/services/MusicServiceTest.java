package org.example.services;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.example.repositories.entities.Music;
import org.example.repositories.entities.Singer;
import org.example.repositories.interfaces.MusicRepository;
import org.example.repositories.interfaces.SingerRepository;
import org.example.repositories.persistences.JPATransactionManager;
import org.example.services.dtos.request.musics.CreateNewMusicRequest;
import org.example.services.dtos.request.musics.GetMusicBySingerRequest;
import org.example.services.dtos.response.musics.GetMusicResponse;
import org.example.services.implementations.MusicServiceImpl;
import org.example.services.interfaces.MusicService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class MusicServiceTest {
    @Mock
    private MusicRepository musicRepository;

    @Mock
    private SingerRepository singerRepository;

    @Mock
    private EntityManager entityManager;

    @Mock
    private JPATransactionManager transactionManager;

    @Mock
    private TypedQuery<Music> musicQuery;

    @InjectMocks
    private MusicService musicService = new MusicServiceImpl();

    @Test
    public void getMusicsBySingerId_shouldThrowNotFoundWhenNotExistedSinger() {
        UUID singerId = UUID.randomUUID();

        when(singerRepository.find("id", singerId, false))
                .thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> musicService.getMusicsBySinger(
                        new GetMusicBySingerRequest(singerId)
                )
        );

        assertEquals("Singer not found", ex.getMessage());
    }

    @Test
    public void getMusicsBySingerId_shouldReturnListOfMusics() {
        Singer singer = new Singer();

        singer.setId(UUID.randomUUID());
        singer.setName("Caitlyn");
        singer.setAge(50);

        List<Music> musics = new ArrayList<>();

        musics.add(new Music(
                new Date(),
                "Dinosaur in the Garden Heaven",
                "Like you know, who else there would be a dinosaur in the Garden Heaven ?",
                1542,
                singer
        ));

        musics.add(new Music(
                new Date(),
                "Chicken in the house",
                "Wonderful chicken in the house",
                130,
                singer
        ));

        when(musicRepository.getEntityManager())
                .thenReturn(entityManager);

        when(entityManager.createQuery(anyString(), eq(Music.class)))
                .thenReturn(musicQuery);

        when(musicQuery.setParameter(anyString(), any()))
                .thenReturn(musicQuery);

        when(musicQuery.getResultList())
                .thenReturn(musics);

        when(singerRepository.find("id", singer.getId(), false))
                .thenReturn(Optional.of(singer));

        List<GetMusicResponse> result = musicService.getMusicsBySinger(new GetMusicBySingerRequest(singer.getId()));

        assertEquals(2, result.size());

        GetMusicResponse firstResponse = result.get(0);

        assertEquals("Dinosaur in the Garden Heaven", firstResponse.name);
        assertEquals(1542, firstResponse.duration);

        GetMusicResponse secondResponse = result.get(1);

        assertEquals("Chicken in the house", secondResponse.name);
        assertEquals(130, secondResponse.duration);
    }

    @Test
    public void createNewMusic_shouldThrowNotFoundWhenNotExistedSinger() {
        Singer singer = new Singer();

        singer.setId(UUID.randomUUID());

        when(singerRepository.find("id", singer.getId(), false))
                .thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> musicService.createMusic(
                new CreateNewMusicRequest(
                        new Date(),
                        "Hanging Love",
                        "All the love having the hang",
                        singer.getId(),
                        1254
                )
        ));

        assertEquals("Singer not found", ex.getMessage());
    }

    @Test
    public void createNewMusic_shouldReturnSuccess() {
        Singer singer = new Singer(
                UUID.randomUUID()
        );
        CreateNewMusicRequest music = new CreateNewMusicRequest(
                new Date(),
                "Hanging Love",
                "All the love having the hang",
                singer.getId(),
                1254
        );

        ArgumentCaptor<Music> captor = ArgumentCaptor.forClass(Music.class);

        when(singerRepository.find("id", singer.getId(), false))
                .thenReturn(Optional.of(singer));

        when(musicRepository.getTransactionManager())
                .thenReturn(transactionManager);

        doAnswer(invocationOnMock -> {
            Runnable r = invocationOnMock.getArgument(0);

            r.run();

            return null;
        }).when(transactionManager).runInTransaction(any(Runnable.class));

        musicService.createMusic(music);

        verify(musicRepository).insert(captor.capture());

        Music saved = captor.getValue();

        assertEquals(music.name, saved.getName());
        assertEquals(music.description, saved.getDescription());
        assertEquals(music.singerId, saved.getSinger().getId());
        assertEquals(music.releaseDate, saved.getReleaseDate());
    }
}
