package org.example.controllers;

import org.example.controllers.implementations.SingerController;
import org.example.services.dtos.request.singers.CreateSingerRequest;
import org.example.services.dtos.request.singers.DeleteSingerRequest;
import org.example.services.dtos.request.singers.GetSingerRequest;
import org.example.services.dtos.request.singers.UpdateSingerRequest;
import org.example.services.dtos.response.BaseResponse;
import org.example.services.dtos.response.singers.GetSingerResponse;
import org.example.services.interfaces.SingerService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SingerControllerTest {
    @Mock
    private SingerService singerService;

    @InjectMocks
    private SingerController singerController;

    @Test
    public void getSingers_shouldReturnSuccessResponse() {
        GetSingerResponse firstSingerResponse = new GetSingerResponse();

        firstSingerResponse.id = UUID.randomUUID();
        firstSingerResponse.name = "Ala dale";
        firstSingerResponse.age = 45;

        GetSingerResponse secondSingerResponse = new GetSingerResponse();

        secondSingerResponse.id = UUID.randomUUID();
        secondSingerResponse.name = "Son Tung Mtp";
        secondSingerResponse.age = 60;

        List<GetSingerResponse> singerResponses = List.of(firstSingerResponse, secondSingerResponse);

        when(singerService.getSingers())
                .thenReturn(singerResponses);

        BaseResponse<List<GetSingerResponse>> baseResponse = singerController.getSingers();

        verify(singerService).getSingers();

        assertTrue(baseResponse.success);
        assertEquals("Get Singer list successfully", baseResponse.message);

        assertNotNull(baseResponse.data);

        assertEquals("Ala dale", baseResponse.data.get(0).name);
        assertEquals("Son Tung Mtp", baseResponse.data.get(1).name);
    }

    @Test
    public void createNewSinger_shouldReturnSuccessResponse() {
        CreateSingerRequest request = new CreateSingerRequest();

        request.name = "Ala dale";
        request.age = 70;

        doNothing().when(singerService).createNewSinger(request.name, request.age);

        BaseResponse<?> response = singerController.createSinger(request);

        verify(singerService).createNewSinger(request.name, request.age);
        assertTrue(response.success);
        assertEquals("Create new Singer successfully", response.message);
    }

    @Test
    public void updateExistedSinger_shouldReturnSuccessResponse() {
        UpdateSingerRequest request = new UpdateSingerRequest(
                UUID.randomUUID(),
                "Adewale",
                90
        );

        doNothing().when(singerService).updateSinger(request);

        BaseResponse<?> response = singerController.updateSinger(request);

        verify(singerService).updateSinger(request);
        assertTrue(response.success);
        assertEquals("Update Singer successfully", response.message);
    }

    @Test
    public void deleteSinger_shouldReturnSuccessResponse() {
        DeleteSingerRequest request = new DeleteSingerRequest();

        request.id = UUID.randomUUID();

        doNothing().when(singerService).deleteSinger(request);

        BaseResponse<?> response = singerController.deleteSinger(request);

        verify(singerService).deleteSinger(request);
        assertTrue(response.success);
        assertEquals("Delete Singer successfully", response.message);
    }

    @Test
    public void getSingerById_shouldReturnSuccessResponseData() {
        GetSingerRequest request = new GetSingerRequest();

        UUID id = UUID.randomUUID();
        request.id = id;

        GetSingerResponse singerResponse = new GetSingerResponse();
        singerResponse.id = id;
        singerResponse.name = "Haythem";
        singerResponse.age = 99;

        when(singerService.getSinger(request.id))
                .thenReturn(singerResponse);

        BaseResponse<GetSingerResponse> baseResponse = singerController.getSinger(request);

        verify(singerService).getSinger(request.id);
        assertTrue(baseResponse.success);
        assertEquals("Get Singer successfully", baseResponse.message);

        assertEquals(id, baseResponse.data.id);
        assertEquals(singerResponse.name, baseResponse.data.name);
        assertEquals(singerResponse.age, baseResponse.data.age);
    }
}
