package org.example.controllers;

import org.example.controllers.annotations.helpers.FileUpload;
import org.example.controllers.implementations.PlayListController;
import org.example.repositories.entities.Singer;
import org.example.services.dtos.request.playlists.*;
import org.example.services.dtos.response.BasePaginationResponse;
import org.example.services.dtos.response.BaseResponse;
import org.example.services.dtos.response.PaginationResponse;
import org.example.services.dtos.response.musics.GetMusicResponse;
import org.example.services.dtos.response.playlists.GetPlayListDetailResponse;
import org.example.services.dtos.response.playlists.GetPlayListResponse;
import org.example.services.dtos.response.singers.GetSingerResponse;
import org.example.services.interfaces.PlayListService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PlayListControllerTest {
    @Mock
    private PlayListService playListService;

    @InjectMocks
    private PlayListController playListController;

    @Test
    public void getPlayLists_shouldReturnSuccessResponseDataWithPagination() {
        GetPlayListsRequest request = new GetPlayListsRequest();

        request.name = "";
        request.page = 1;
        request.pageSize = 10;

        Singer singer = new Singer();

        singer.setId(UUID.randomUUID());
        singer.setName("Coner");
        singer.setAge(456);

        GetPlayListResponse firstPlayList = new GetPlayListResponse();

        firstPlayList.id = UUID.randomUUID();
        firstPlayList.name = "Awesome Summer";
        firstPlayList.description = "Such a wonderful summer at Iceland";
        firstPlayList.singerId = singer.getId();

        GetPlayListResponse secondPlayList = new GetPlayListResponse();

        secondPlayList.id = UUID.randomUUID();
        secondPlayList.name = "Awful Autumn";
        secondPlayList.description = "Help me to escape the crazy Autumn";
        secondPlayList.singerId = singer.getId();

        List<GetPlayListResponse> playListResponses = List.of(firstPlayList, secondPlayList);

        PaginationResponse<GetPlayListResponse> paginationResponse = new PaginationResponse<>(
                1,
                10,
                1,
                2,
                2,
                playListResponses
        );

        when(playListService.getPlayLists(request))
                .thenReturn(paginationResponse);

        BasePaginationResponse<GetPlayListResponse> basePaginationResponse =
                playListController.getPlayLists(request);

        verify(playListService).getPlayLists(request);

        assertTrue(basePaginationResponse.success);
        assertEquals("Get Play Lists successfully", basePaginationResponse.message);
        assertEquals(paginationResponse.page, basePaginationResponse.page);
        assertEquals(paginationResponse.pageSize, basePaginationResponse.pageSize);
        assertEquals(paginationResponse.currentPageRecords, basePaginationResponse.currentPageRecords);
        assertEquals(paginationResponse.totalPage, basePaginationResponse.totalPage);
        assertEquals(paginationResponse.totalRecords, basePaginationResponse.totalRecords);

        assertEquals(paginationResponse.data.get(0).id, basePaginationResponse.data.get(0).id);
        assertEquals(paginationResponse.data.get(0).name, basePaginationResponse.data.get(0).name);
        assertEquals(paginationResponse.data.get(0).description, basePaginationResponse.data.get(0).description);
        assertEquals(paginationResponse.data.get(0).singerId, basePaginationResponse.data.get(0).singerId);

        assertEquals(paginationResponse.data.get(1).id, basePaginationResponse.data.get(1).id);
        assertEquals(paginationResponse.data.get(1).name, basePaginationResponse.data.get(1).name);
        assertEquals(paginationResponse.data.get(1).description, basePaginationResponse.data.get(1).description);
        assertEquals(paginationResponse.data.get(1).singerId, basePaginationResponse.data.get(1).singerId);
    }

    @Test
    void deletePlayList_shouldReturnSuccessResponse() {
        DeletePlayListRequest request = new DeletePlayListRequest();
        request.id = UUID.randomUUID();

        doNothing().when(playListService)
                .deletePlayList(request);

        BaseResponse<?> response =
                playListController.deletePlayList(request);

        verify(playListService).deletePlayList(request);

        assertTrue(response.success);
        assertEquals("Delete Play List successfully", response.message);
    }

    @Test
    void updatePlayList_shouldReturnSuccessResponse_whenFileProvided() {
        UpdatePlayListRequest request = new UpdatePlayListRequest();
        request.id = UUID.randomUUID();
        request.name = "Updated name";

        FileUpload fileUpload =
                new FileUpload("image.png", new byte[]{1, 2, 3});

        doNothing().when(playListService)
                .updatePlayList(request, fileUpload);

        BaseResponse<?> response =
                playListController.updatePlayList(request, fileUpload);

        verify(playListService)
                .updatePlayList(request, fileUpload);

        assertTrue(response.success);
        assertEquals("Update Play List successfully", response.message);
    }

    @Test
    void updatePlayList_shouldWorkWithoutFile() {
        UpdatePlayListRequest request = new UpdatePlayListRequest();
        request.id = UUID.randomUUID();
        request.name = "Updated name";

        BaseResponse<?> response =
                playListController.updatePlayList(request, null);

        verify(playListService)
                .updatePlayList(request, null);

        assertTrue(response.success);
    }

    @Test
    void createNewPlayList_shouldReturnSuccess_whenFileProvided() {
        CreateNewPlayListRequest request = new CreateNewPlayListRequest();
        request.name = "Spring";
        request.description = "New Spring";
        request.singerId = UUID.randomUUID();
        request.musicIds = List.of(UUID.randomUUID());

        FileUpload file =
                new FileUpload("image.png", new byte[]{1, 2, 3});

        doNothing().when(playListService)
                .createNewPlayList(request, file);

        BaseResponse<?> response =
                playListController.createNewPlayList(request, file);

        verify(playListService)
                .createNewPlayList(request, file);

        assertTrue(response.success);
        assertEquals("Create new Play List successfully", response.message);
    }

    @Test
    void getPlayListDetails_shouldReturnResponseSuccess() {
        UUID id = UUID.randomUUID();

        GetPlayListDetailRequest request = new GetPlayListDetailRequest();
        request.id = id;

        GetPlayListDetailResponse response = new GetPlayListDetailResponse();
        response.id = id;
        response.name = "Summer vibe";
        response.description = "The Summer vibe seem to be peaceful";
        response.singer = new GetSingerResponse(
                UUID.randomUUID(),
                "Exile",
                13
        );
        response.musics = List.of(new GetMusicResponse(
                        UUID.randomUUID(),
                        new Date(),
                        "Surfing on Hawaii Beach",
                        "Wonderful summer vibe at Hawaii Beaches",
                        65
                ), new GetMusicResponse(
                        UUID.randomUUID(),
                        new Date(),
                        "Staying rewind at the yard",
                        "Being relaxed at the summer in the yard",
                        50
                )
        );

        when(playListService.getPlayListDetail(request))
                .thenReturn(response);

        BaseResponse<GetPlayListDetailResponse> baseResponse = playListController.getPlayListDetails(request);

        verify(playListService).getPlayListDetail(request);

        assertTrue(baseResponse.success);
        assertEquals("Get Play List Details successfully", baseResponse.message);
        assertEquals(response.id, baseResponse.data.id);
        assertEquals(response.name, baseResponse.data.name);
        assertEquals(response.description, baseResponse.data.description);

        assertEquals(response.singer.id, baseResponse.data.singer.id);
        assertEquals(response.singer.name, baseResponse.data.singer.name);
        assertEquals(response.singer.age, baseResponse.data.singer.age);

        assertEquals(2, baseResponse.data.musics.size());

        assertEquals(response.musics.get(0).id, baseResponse.data.musics.get(0).id);
        assertEquals(response.musics.get(0).name, baseResponse.data.musics.get(0).name);
        assertEquals(response.musics.get(0).description, baseResponse.data.musics.get(0).description);
        assertEquals(response.musics.get(0).duration, baseResponse.data.musics.get(0).duration);

        assertEquals(response.musics.get(1).id, baseResponse.data.musics.get(1).id);
        assertEquals(response.musics.get(1).name, baseResponse.data.musics.get(1).name);
        assertEquals(response.musics.get(1).description, baseResponse.data.musics.get(1).description);
        assertEquals(response.musics.get(1).duration, baseResponse.data.musics.get(1).duration);
    }
}
