package org.example.controllers;

import org.example.controllers.implementations.MusicController;
import org.example.services.dtos.request.musics.CreateNewMusicRequest;
import org.example.services.dtos.request.musics.GetMusicBySingerRequest;
import org.example.services.dtos.response.BaseResponse;
import org.example.services.dtos.response.musics.GetMusicResponse;
import org.example.services.interfaces.MusicService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class MusicControllerTest {
    @Mock
    private MusicService musicService;

    @InjectMocks
    private MusicController musicController;

    @Test
    public void createNewMusic_shouldReturnSuccessResponse() {
        CreateNewMusicRequest request = new CreateNewMusicRequest();
        request.name = "Spring";
        request.duration = 120;

        doNothing().when(musicService).createMusic(request);

        BaseResponse<?> response =
                musicController.createNewMusic(request);

        verify(musicService).createMusic(request);

        assertTrue(response.success);
        assertEquals("Create new Music successfully", response.message);
    }

    @Test
    public void getMusicsBySinger_shouldReturnSuccessResponseData() {
        GetMusicBySingerRequest request = new GetMusicBySingerRequest(UUID.randomUUID());

        GetMusicResponse firstMusicResponse = new GetMusicResponse();

        firstMusicResponse.id = UUID.randomUUID();
        firstMusicResponse.name = "Artist in the Field";
        firstMusicResponse.description = "In the Field that full of joys";
        firstMusicResponse.duration = 130;
        firstMusicResponse.releaseDate = new Date();

        GetMusicResponse secondMusicResponse = new GetMusicResponse();

        secondMusicResponse.id = UUID.randomUUID();
        secondMusicResponse.name = "Cow moo";
        secondMusicResponse.description = "Moo Moo Moo";
        secondMusicResponse.duration = 45;
        secondMusicResponse.releaseDate = new Date();

        List<GetMusicResponse> musicResponses = List.of(firstMusicResponse,secondMusicResponse);

        when(musicService.getMusicsBySinger(request))
                .thenReturn(musicResponses);

        BaseResponse<List<GetMusicResponse>> response =
                musicController.getMusics(request);

        verify(musicService).getMusicsBySinger(request);

        assertTrue(response.success);
        assertEquals("Get Musics successfully", response.message);
        assertNotNull(response.data);
        assertEquals(2, response.data.size());
        assertEquals("Artist in the Field", response.data.get(0).name);
        assertEquals("Cow moo", response.data.get(1).name);
    }
}
