package org.example.repositories.interfaces;

import jakarta.persistence.EntityManager;
import org.example.repositories.persistences.JPATransactionManager;

import java.util.List;
import java.util.Optional;

public interface GenericRepository<T> {
    Optional<T> find(String fieldName, Object value, boolean includeDeleted);
    void insert(T entity);
    void update(T entity);
    void delete(T entity);
    void deletePermanent(T entity);
    void insertRange(List<T> entities);
    EntityManager getEntityManager();
    JPATransactionManager getTransactionManager();
}
