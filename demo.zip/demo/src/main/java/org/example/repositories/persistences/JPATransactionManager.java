package org.example.repositories.persistences;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.function.Supplier;

@ApplicationScoped
public class JPATransactionManager {
    @Inject
    private EntityManager entityManager;

    public <T> T doInTransaction(Supplier<T> work) {
        EntityTransaction tx = entityManager.getTransaction();

        try {
            tx.begin();
            T result = work.get();
            tx.commit();
            return result;

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    public void runInTransaction(Runnable work) {
        EntityTransaction tx = entityManager.getTransaction();

        try {
            tx.begin();
            work.run();
            tx.commit();

        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            throw e;
        }
    }

    public EntityManager getEntityManager() {
        return entityManager;
    }
}
