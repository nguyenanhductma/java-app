package org.example.repositories.implementations;

import jakarta.enterprise.context.ApplicationScoped;
import org.example.repositories.entities.PlayList;
import org.example.repositories.interfaces.PlayListRepository;

@ApplicationScoped
public class PlayListRepositoryImpl extends GenericRepositoryImpl<PlayList> implements PlayListRepository {
}
