package org.example.repositories.persistences;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Produces;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;


@ApplicationScoped
public class JPAProducer {

    private final EntityManagerFactory emf = Persistence.createEntityManagerFactory("MyPU");

    @Produces
    @ApplicationScoped
    public EntityManagerFactory produceEMF() {
        return emf;
    }

    @Produces
    @ApplicationScoped
    public EntityManager produceEM(EntityManagerFactory emf) {
        return emf.createEntityManager();
    }
}