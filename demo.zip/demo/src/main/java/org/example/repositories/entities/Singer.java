package org.example.repositories.entities;

import jakarta.persistence.*;

import java.util.List;
import java.util.UUID;

@Entity()
@Table(name = "singers")
public class Singer extends EntityBase {
    private String name;
    private int age;

    @Column(name = "avatar_url")
    private String avatarUrl;

    @OneToMany(mappedBy = "singer", cascade = CascadeType.ALL)
    private List<Music> musics;

    @OneToMany(mappedBy = "singer", cascade = CascadeType.ALL)
    private List<PlayList> playLists;

    public Singer() {
    }

    public Singer(UUID id) {
        super(id);
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public Singer(String name, int age, List<Music> musics, List<PlayList> playLists, String avatarUrl) {
        this.name = name;
        this.age = age;
        this.musics = musics;
        this.playLists = playLists;
        this.avatarUrl = avatarUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public List<Music> getMusics() {
        return musics;
    }

    public void setMusics(List<Music> musics) {
        this.musics = musics;
    }

    public List<PlayList> getPlayLists() {
        return playLists;
    }

    public void setPlayLists(List<PlayList> playLists) {
        this.playLists = playLists;
    }
}
