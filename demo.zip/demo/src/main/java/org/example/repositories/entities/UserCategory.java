package org.example.repositories.entities;

public class UserCategory {
}
