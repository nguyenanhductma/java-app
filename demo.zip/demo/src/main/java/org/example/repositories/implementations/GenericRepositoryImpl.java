package org.example.repositories.implementations;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import org.example.repositories.interfaces.GenericRepository;
import org.example.repositories.persistences.JPATransactionManager;

import java.lang.reflect.ParameterizedType;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class GenericRepositoryImpl<T> implements GenericRepository<T> {
    @Inject
    private EntityManager entityManager;

    @Inject
    private JPATransactionManager transactionManager;

    protected Class<T> entityClass;

    public EntityManager getEntityManager() {
        return entityManager;
    }

    public JPATransactionManager getTransactionManager() {
        return transactionManager;
    }

    @SuppressWarnings("unchecked")

    public GenericRepositoryImpl() {
        this.entityClass = (Class<T>)
                ((ParameterizedType) getClass().getGenericSuperclass())
                        .getActualTypeArguments()[0];
    }

    @Override
    public Optional<T> find(String fieldName, Object value, boolean includeDeleted) {
        String jpql = includeDeleted
                ? "SELECT e FROM " + entityClass.getSimpleName() + " e WHERE e." + fieldName + " = :value"
                : "SELECT e FROM " + entityClass.getSimpleName() + " e WHERE e.deletedTime IS NULL AND e." + fieldName + " = :value";

        List<T> result = entityManager.createQuery(jpql, entityClass)
                .setParameter("value", value)
                .setMaxResults(1)
                .getResultList();

        return result.stream().findFirst();
    }

    @Override
    public void insert(T entity) {
        entityManager.persist(entity);
    }

    @Override
    public void update(T entity) {
        entityManager.merge(entity);
    }

    @Override
    public void delete(T entity) {
        try {
            entity.getClass().getMethod("setDeletedTime", Date.class)
                    .invoke(entity, new Date());
            entityManager.merge(entity);

        } catch (Exception e) {
            throw new RuntimeException("Entity missing deletedTime setter", e);
        }
    }

    @Override
    public void deletePermanent(T entity) {
        entityManager.remove(entityManager.contains(entity) ? entity : entityManager.merge(entity));
    }

    @Override
    public void insertRange(List<T> entities) {
        for (T e : entities) {
            entityManager.persist(e);
        }
    }

//    public PaginationResponse<T> paginate(String jpql, int page, int pageSize) {
//        List<T> data = em.createQuery(jpql, type)
//                .setFirstResult((page - 1) * pageSize)
//                .setMaxResults(pageSize)
//                .getResultList();
//
//        Long totalRecords = em.createQuery("SELECT COUNT(e) FROM " + type.getSimpleName() + " e", Long.class)
//                .getSingleResult();
//
//        return new PaginationResponse<>(data, page, pageSize, totalRecords.intValue(), data.size());
//    }
}
