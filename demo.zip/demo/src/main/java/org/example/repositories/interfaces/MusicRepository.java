package org.example.repositories.interfaces;

import org.example.repositories.entities.Music;

public interface MusicRepository extends GenericRepository<Music> {
}
