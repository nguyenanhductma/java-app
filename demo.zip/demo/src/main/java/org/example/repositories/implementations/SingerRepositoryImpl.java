package org.example.repositories.implementations;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.example.repositories.entities.Singer;
import org.example.repositories.interfaces.SingerRepository;
import org.example.repositories.persistences.JPATransactionManager;

@ApplicationScoped
public class SingerRepositoryImpl extends GenericRepositoryImpl<Singer> implements SingerRepository {

}
