package org.example.repositories.implementations;

import jakarta.enterprise.context.ApplicationScoped;
import org.example.repositories.entities.Music;
import org.example.repositories.interfaces.MusicRepository;

@ApplicationScoped
public class MusicRepositoryImpl extends GenericRepositoryImpl<Music> implements MusicRepository {
}
