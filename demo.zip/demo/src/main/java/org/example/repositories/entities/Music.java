package org.example.repositories.entities;

import jakarta.persistence.*;

import java.util.Date;
import java.util.UUID;

@Entity()
@Table(name = "musics")
public class Music extends EntityBase {
    @Column(name = "released_date")
    private Date releaseDate;
    private String name;
    private String description;
    private int duration;

    @ManyToOne()
    @JoinColumn(name = "singer_id")
    private Singer singer;

    @ManyToOne
    @JoinColumn(name = "play_list_id")
    private PlayList playList;

    public Music() {
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public Music(UUID id, Date releaseDate, String name, String description, int duration, Singer singer) {
        super(id);
        this.releaseDate = releaseDate;
        this.name = name;
        this.description = description;
        this.duration = duration;
        this.singer = singer;
    }

    public Music(Date releaseDate, String name, String description, int duration, Singer singer) {
        this.releaseDate = releaseDate;
        this.name = name;
        this.description = description;
        this.duration = duration;
        this.singer = singer;
    }

    public Music(Date releaseDate, String name, String description, int duration, Singer singer, PlayList playList) {
        this.releaseDate = releaseDate;
        this.name = name;
        this.description = description;
        this.duration = duration;
        this.singer = singer;
        this.playList = playList;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Singer getSinger() {
        return singer;
    }

    public void setSinger(Singer singer) {
        this.singer = singer;
    }

    public PlayList getPlayList() {
        return playList;
    }

    public void setPlayList(PlayList playList) {
        this.playList = playList;
    }
}
