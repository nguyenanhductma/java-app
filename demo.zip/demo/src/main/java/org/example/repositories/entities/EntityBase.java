package org.example.repositories.entities;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import org.hibernate.annotations.GenericGenerator;

import java.util.Date;
import java.util.UUID;

@MappedSuperclass
public abstract class EntityBase {
    @Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid2")
    private UUID id;

    @Column(name = "created_time")
    private Date createdTime;

    @Column(name = "last_updated_time")
    private Date lastUpdatedTime;

    @Column(name = "deleted_time")
    private Date deletedTime;

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public Date getLastUpdatedTime() {
        return lastUpdatedTime;
    }

    public void setLastUpdatedTime(Date lastUpdatedTime) {
        this.lastUpdatedTime = lastUpdatedTime;
    }

    public Date getDeletedTime() {
        return deletedTime;
    }

    public void setDeletedTime(Date deletedTime) {
        this.deletedTime = deletedTime;
    }

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public EntityBase(UUID id, Date createdTime, Date lastUpdatedTime, Date deletedTime) {
        this.id = id;
        this.createdTime = createdTime;
        this.lastUpdatedTime = lastUpdatedTime;
        this.deletedTime = deletedTime;
    }

    public EntityBase(UUID id) {
        this.id = id;
    }

    public EntityBase() {
        createdTime = lastUpdatedTime = new Date();
    }
}
