package org.example.repositories.entities;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "play_lists")
public class PlayList extends EntityBase {
    private String name;
    private String description;

    @Column(name = "image_url")
    private String imageUrl;

    @ManyToOne()
    @JoinColumn(name = "singer_id")
    private Singer singer;

    @OneToMany(mappedBy = "playList")
    private List<Music> musics;

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public PlayList(String name, String description, String imageUrl, Singer singer, List<Music> musics) {
        this.name = name;
        this.description = description;
        this.imageUrl = imageUrl;
        this.singer = singer;
        this.musics = musics;
    }

    public PlayList(String name, String description, Singer singer, List<Music> musics) {
        this.name = name;
        this.description = description;
        this.singer = singer;
        this.musics = musics;
    }

    public PlayList() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Singer getSinger() {
        return singer;
    }

    public void setSinger(Singer singer) {
        this.singer = singer;
    }

    public List<Music> getMusics() {
        return musics;
    }

    public void setMusics(List<Music> musics) {
        this.musics = musics;
    }
}
