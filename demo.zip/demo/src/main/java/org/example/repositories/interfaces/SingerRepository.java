package org.example.repositories.interfaces;

import org.example.repositories.entities.Singer;

public interface SingerRepository extends GenericRepository<Singer> {
}
