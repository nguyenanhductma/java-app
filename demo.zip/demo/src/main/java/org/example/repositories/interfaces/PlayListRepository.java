package org.example.repositories.interfaces;

import org.example.repositories.entities.PlayList;

public interface PlayListRepository extends GenericRepository<PlayList> {
}
