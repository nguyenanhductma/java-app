package org.example.controllers.annotations.helpers;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ClassScanner {
    public static List<Class<?>> scan(String packageName) {
        List<Class<?>> classes = new ArrayList<>();
        String path = packageName.replace('.', '/');

        try {
            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
            URL resource = classLoader.getResource(path);

            if (resource == null) return classes;

            File directory = new File(resource.getFile());
            if (!directory.exists()) return classes;

            for (String file : Objects.requireNonNull(directory.list())) {
                if (file.endsWith(".class")) {
                    String className = packageName + "." + file.replace(".class", "");
                    classes.add(Class.forName(className));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return classes;
    }
}
