package org.example.controllers.annotations;

import org.example.controllers.annotations.retentions.Inject;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class DIContainer {
    private static final Map<Class<?>, Object> singletons = new HashMap<>();

    public <T> T get(Class<T> type) {
        try {
            if (singletons.containsKey(type)) {
                return type.cast(singletons.get(type));
            }

            T instance = createInstance(type);
            singletons.put(type, instance);

            injectFields(instance);

            return instance;
        } catch (Exception e) {
            throw new RuntimeException("DI create error: " + type, e);
        }
    }

    public static <T> void register(Class<T> type, T instance) {
        singletons.put(type, instance);
    }

    public static <T> T resolve(Class<T> type) {
        return type.cast(singletons.get(type));
    }

    private <T> T createInstance(Class<T> type) throws Exception {
        Constructor<?>[] constructors = type.getDeclaredConstructors();

        for (Constructor<?> c : constructors) {
            if (c.getParameterCount() == 0) {
                c.setAccessible(true);
                return type.cast(c.newInstance());
            }
        }

        throw new RuntimeException("No default constructor in " + type);
    }

    private void injectFields(Object instance) throws Exception {
        for (Field field : instance.getClass().getDeclaredFields()) {
            if (field.isAnnotationPresent(Inject.class)) {
                Class<?> fieldType = field.getType();
                Object dependency = get(fieldType);
                field.setAccessible(true);
                field.set(instance, dependency);
            }
        }
    }
}
