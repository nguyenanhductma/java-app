package org.example.controllers.annotations;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.example.controllers.annotations.helpers.ClassScanner;
import org.example.controllers.annotations.helpers.MultipartParser;
import org.example.controllers.annotations.helpers.MultipartResult;
import org.example.controllers.annotations.helpers.RequestParameterHelper;
import org.example.controllers.annotations.retentions.Controller;
import org.example.controllers.annotations.retentions.FormFile;
import org.example.controllers.annotations.retentions.HttpMethod;
import org.example.controllers.annotations.retentions.RequestParameter;
import org.example.helpers.JsonConverter;
import org.example.services.dtos.response.BaseResponse;
import org.jboss.weld.environment.se.WeldContainer;
import org.reflections.Reflections;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@ApplicationScoped
public class AnnotationRouter {
    private final HttpServer httpServer;
    private static final Map<String, Map<String, HandlerMethod>> routes = new HashMap<>();

    @Inject
    private WeldContainer weldContainer;

    @Inject
    public AnnotationRouter() throws IOException {
        this.httpServer = HttpServer.create(new InetSocketAddress(8080), 0);
    }

//    public void scanControllers(String basePackage) {
//        List<Class<?>> classes = ClassScanner.scan(basePackage);
//
//        for (Class<?> cls : classes) {
//            Object controller = weldContainer.select(cls).get();
//            registerController(controller);
//        }
//    }

    public void scanControllers(String basePackage) {
        Reflections reflections = new Reflections(basePackage);

        Set<Class<?>> classes = reflections.getTypesAnnotatedWith(Controller.class);

        for (Class<?> cls : classes) {
            Object controller = weldContainer.select(cls).get();
            registerController(controller);
        }
    }

    private Class<?> unwrapClass(Object bean) {
        Class<?> cls = bean.getClass();

        if (cls.getName().contains("WeldClientProxy")) {
            return cls.getSuperclass();
        }
        return cls;
    }

    public void registerController(Object controller) {
        Class<?> cls = unwrapClass(controller);

        String prefix = "";

        if (cls.isAnnotationPresent(Controller.class)) {
            prefix = cls.getAnnotation(Controller.class).value();

            if (!prefix.startsWith("/")) {
                prefix = "/" + prefix;
            }

            if (prefix.endsWith("/")) {
                prefix = prefix.substring(0, prefix.length() - 1);
            }
        }

        for (Method method : cls.getDeclaredMethods()) {
            if (method.isAnnotationPresent(HttpMethod.GET.class)) {
                bind(prefix + method.getAnnotation(HttpMethod.GET.class).value(),
                        "GET", controller, method);
            }
            if (method.isAnnotationPresent(HttpMethod.POST.class)) {
                bind(prefix + method.getAnnotation(HttpMethod.POST.class).value(),
                        "POST", controller, method);
            }
            if (method.isAnnotationPresent(HttpMethod.PUT.class)) {
                bind(prefix + method.getAnnotation(HttpMethod.PUT.class).value(),
                        "PUT", controller, method);
            }
            if (method.isAnnotationPresent(HttpMethod.PATCH.class)) {
                bind(prefix + method.getAnnotation(HttpMethod.PATCH.class).value(),
                        "PATCH", controller, method);
            }
            if (method.isAnnotationPresent(HttpMethod.DELETE.class)) {
                bind(prefix + method.getAnnotation(HttpMethod.DELETE.class).value(),
                        "DELETE", controller, method);
            }
        }
    }

    private void bind(String path, String httpMethod, Object controller, Method method) {
        routes.putIfAbsent(path, new HashMap<>());
        routes.get(path).put(httpMethod.toUpperCase(), new HandlerMethod(controller, method));
    }

    public void startContexts() {
        for (String path : routes.keySet()) {
            httpServer.createContext(path, exchange -> {
                exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
                exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
                exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "*");

                String requestPath = exchange.getRequestURI().getPath();

                if (requestPath.length() > 1 && requestPath.endsWith("/")) {
                    requestPath = requestPath.substring(0, requestPath.length() - 1);
                }

                String httpMethod = exchange.getRequestMethod().toUpperCase();

                if (httpMethod.equalsIgnoreCase("OPTIONS")) {
                    httpMethod =
                            exchange.getRequestHeaders()
                                    .getFirst("Access-Control-Request-Method")
                                    .toUpperCase();
                }


                HandlerMethod handlerMethod = routes.get(path).get(httpMethod);

                Map<String, HandlerMethod> methods = routes.get(requestPath);

                if (methods == null) {
                    exchange.sendResponseHeaders(404, 0);
                    exchange.getResponseBody().write("Not Found".getBytes());
                    exchange.close();
                    return;
                }

//                if (!requestMethod.equalsIgnoreCase(httpMethod)) {
//                    exchange.sendResponseHeaders(405, 0);
//                    exchange.getResponseBody().write("Method Not Allowed".getBytes());
//                    exchange.close();
//                    return;
//                }

                if (methods.get(httpMethod) == null) {
                    exchange.sendResponseHeaders(405, 0);
                    exchange.getResponseBody().write("Method Not Allowed".getBytes());
                    exchange.close();
                    return;
                }
                try {
                    Object[] args = buildMethodArguments(handlerMethod.method, exchange);
                    Object object = handlerMethod.method.invoke(handlerMethod.controller, args);

                    String result = JsonConverter.toJson(object);

//                    exchange.sendResponseHeaders(200, result.length());
//                    exchange.getResponseBody().write(result.getBytes());

                    byte[] responseBytes = result.getBytes(StandardCharsets.UTF_8);

                    exchange.sendResponseHeaders(200, responseBytes.length);
                    exchange.getResponseBody().write(responseBytes);

                    exchange.close();

                } catch (Exception e) {
                    Throwable cause = e;
                    if (e instanceof InvocationTargetException ite) {
                        cause = ite.getTargetException();
                    }

                    String message = cause.getMessage();
                    if (message == null || message.isBlank()) {
                        message = "Internal Server Error";
                    }

                    BaseResponse<Object> response = new BaseResponse<>(
                            false,
                            message
                    );

                    byte[] body = JsonConverter.toJson(response)
                            .getBytes(StandardCharsets.UTF_8);

                    exchange.getResponseHeaders().set("Content-Type", "application/json");
                    exchange.sendResponseHeaders(500, body.length);

                    exchange.getResponseBody().write(body);
                    exchange.close();
                }
            });
        }
    }

    private Object[] buildMethodArguments(Method method, HttpExchange exchange) {
        Parameter[] parameters = method.getParameters();
        Object[] args = new Object[parameters.length];

        String contentType = exchange.getRequestHeaders().getFirst("Content-Type");
        boolean isMultipart = contentType != null && contentType.startsWith("multipart/form-data");

        MultipartResult multipartResult = null;
        if (isMultipart) {
            try {
                multipartResult = MultipartParser.parse(exchange);
            } catch (Exception e) {
                throw new RuntimeException("Failed to parse multipart", e);
            }
        }

        for (int i = 0; i < parameters.length; i++) {
            Parameter param = parameters[i];

            if (param.getType() == HttpExchange.class) {
                args[i] = exchange;
                continue;
            }
            if (isMultipart && param.isAnnotationPresent(FormFile.class)) {
                String fieldName = param.getAnnotation(FormFile.class).value();
                args[i] = multipartResult.files.get(fieldName);
                continue;
            }

            if (isMultipart && param.isAnnotationPresent(RequestParameter.RequestBody.class)) {
                args[i] = RequestParameterHelper.mapToObject(
                        multipartResult.formFields,
                        param.getType()
                );
                continue;
            }

            if (param.isAnnotationPresent(RequestParameter.RequestBody.class)) {
                try {
                    args[i] = JsonConverter.fromJson(RequestParameterHelper.readRequestBody(exchange), param.getType());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                continue;
            }

            if (param.isAnnotationPresent(RequestParameter.QueryParam.class)) {
                Map<String, Object> queryMap = RequestParameterHelper.getQueryParams(exchange);
                args[i] = JsonConverter.convertMapToObject(queryMap, param.getType());
                continue;
            }

            args[i] = null;
        }

        return args;
    }

    public void registerHealthEndpoint() {
        httpServer.createContext("/health", exchange -> {
            if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }

            byte[] response = "OK".getBytes();
            exchange.sendResponseHeaders(200, response.length);
            exchange.getResponseBody().write(response);
            exchange.close();
        });
    }

    public void start() {
        httpServer.start();
    }
}

