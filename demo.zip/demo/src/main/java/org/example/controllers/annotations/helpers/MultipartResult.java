package org.example.controllers.annotations.helpers;

import java.util.HashMap;
import java.util.Map;

public class MultipartResult {
    public Map<String, String> formFields = new HashMap<>();
    public Map<String, FileUpload> files = new HashMap<>();
}

