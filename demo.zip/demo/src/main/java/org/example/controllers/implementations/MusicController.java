package org.example.controllers.implementations;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.example.controllers.annotations.retentions.Controller;
import org.example.controllers.annotations.retentions.HttpMethod;
import org.example.controllers.annotations.retentions.RequestParameter;
import org.example.services.dtos.request.musics.CreateNewMusicRequest;
import org.example.services.dtos.request.musics.GetMusicBySingerRequest;
import org.example.services.dtos.request.musics.UpdateMusicRequest;
import org.example.services.dtos.response.BaseResponse;
import org.example.services.dtos.response.musics.GetMusicResponse;
import org.example.services.interfaces.MusicService;

import java.util.List;

@ApplicationScoped
@Controller("musics")
public class MusicController {
    @Inject
    private MusicService musicService;

    @HttpMethod.POST("")
    public BaseResponse<?> createNewMusic(@RequestParameter.RequestBody CreateNewMusicRequest request) {
        this.musicService.createMusic(request);

        return new BaseResponse<>(
                true,
                "Create new Music successfully"
        );
    }

    @HttpMethod.POST("/update")
    public BaseResponse<?> updateMusic(@RequestParameter.RequestBody UpdateMusicRequest request) {
        this.musicService.updateMusic(request);

        return new BaseResponse<>(
                true,
                "Update Music successfully"
        );
    }

    @HttpMethod.GET("")
    public BaseResponse<List<GetMusicResponse>> getMusics(@RequestParameter.QueryParam GetMusicBySingerRequest request) {
        return new BaseResponse<>(
                true,
                "Get Musics successfully",
                this.musicService.getMusicsBySinger(request)
        );
    }
}
