package org.example.controllers.annotations.helpers;

import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class MultipartParser {

    public static MultipartResult parse(HttpExchange exchange) throws IOException {
        MultipartResult result = new MultipartResult();

        String contentType = exchange.getRequestHeaders().getFirst("Content-Type");
        String boundary = contentType.split("boundary=")[1];

        byte[] bodyBytes = exchange.getRequestBody().readAllBytes();
        String body = new String(bodyBytes, StandardCharsets.ISO_8859_1);

        String[] parts = body.split("--" + boundary);

        for (String part : parts) {
            if (part.isBlank() || part.equals("--")) continue;

            String[] sections = part.split("\r\n\r\n", 2);
            if (sections.length < 2) continue;

            String headers = sections[0];
            String data = sections[1].trim();

            String fieldName = extract(headers, "name=\"", "\"");
            if (fieldName == null) continue;

            String fileName = extract(headers, "filename=\"", "\"");

            if (fileName != null && !fileName.isBlank()) {
                result.files.put(fieldName, new FileUpload(fileName, data.getBytes(StandardCharsets.ISO_8859_1)));
            } else {
                result.formFields.put(fieldName, data);
            }
        }

        return result;
    }

    private static String extract(String text, String start, String end) {
        int i = text.indexOf(start);
        if (i == -1) return null;
        int j = text.indexOf(end, i + start.length());
        if (j == -1) return null;
        return text.substring(i + start.length(), j);
    }
}
