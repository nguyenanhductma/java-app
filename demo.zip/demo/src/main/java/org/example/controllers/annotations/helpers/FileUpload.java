package org.example.controllers.annotations.helpers;

public class FileUpload {
    public final String fileName;
    public final byte[] bytes;

    public FileUpload(String fileName, byte[] bytes) {
        this.fileName = fileName;
        this.bytes = bytes;
    }
}
