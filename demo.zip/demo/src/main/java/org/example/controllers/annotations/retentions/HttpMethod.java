package org.example.controllers.annotations.retentions;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public @interface HttpMethod {
    @Retention(RetentionPolicy.RUNTIME)
    public @interface GET {
        String value();
    }

    @Retention(RetentionPolicy.RUNTIME)
    public @interface POST {
        String value();
    }

    @Retention(RetentionPolicy.RUNTIME)
    public @interface PUT {
        String value();
    }

    @Retention(RetentionPolicy.RUNTIME)
    public @interface PATCH {
        String value();
    }

    @Retention(RetentionPolicy.RUNTIME)
    public @interface DELETE {
        String value();
    }
}
