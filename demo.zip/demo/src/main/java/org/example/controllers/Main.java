package org.example.controllers;

import org.example.controllers.annotations.AnnotationRouter;
import org.example.services.kafka.SubscriberHandler;
import org.example.services.kafka.events.cores.EventRegistry;
import org.example.services.kafka.publishers.cores.KafkaEventPublisher;
import org.example.services.kafka.publishers.cores.KafkaPublisherManager;
import org.example.services.kafka.subscribers.cores.KafkaEventSubscriber;
import org.example.services.kafka.subscribers.cores.KafkaMultiTopicSubscriber;
import org.jboss.weld.environment.se.Weld;
import org.jboss.weld.environment.se.WeldContainer;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Weld weld = new Weld();
        WeldContainer weldContainer = weld.initialize();

        AnnotationRouter router = weldContainer.select(AnnotationRouter.class).get();

        router.scanControllers("org.example.controllers.implementations");

        String bootstrap = "localhost:9092";

        registerKafka(bootstrap, weldContainer);

        router.registerHealthEndpoint();
        router.startContexts();
        router.start();

    }

    public static void registerKafka(String bootstrap, WeldContainer weldContainer) {
        KafkaPublisherManager publisherManager =
                new KafkaPublisherManager();

        publisherManager.registerKafkaPublisherManager(bootstrap);

        KafkaEventPublisher publisher =
                new KafkaEventPublisher();

        KafkaMultiTopicSubscriber rawSubscriber =
                new KafkaMultiTopicSubscriber(
                        bootstrap,
                        "transaction-service",
                        EventRegistry.allTopics()
                );

        KafkaEventSubscriber subscriber =
                new KafkaEventSubscriber(rawSubscriber);

        SubscriberHandler handler = weldContainer.select(SubscriberHandler.class).get();

        handler.subscribeKafkaEvent(subscriber);
    }
}