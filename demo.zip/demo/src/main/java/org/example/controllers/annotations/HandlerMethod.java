package org.example.controllers.annotations;

import java.lang.reflect.Method;

public class HandlerMethod {
    Object controller;
    Method method;

    public HandlerMethod(Object controller, Method method) {
        this.controller = controller;
        this.method = method;
    }
}
