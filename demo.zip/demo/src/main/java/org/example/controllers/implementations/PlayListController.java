package org.example.controllers.implementations;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.example.controllers.annotations.helpers.FileUpload;
import org.example.controllers.annotations.retentions.Controller;
import org.example.controllers.annotations.retentions.FormFile;
import org.example.controllers.annotations.retentions.HttpMethod;
import org.example.controllers.annotations.retentions.RequestParameter;
import org.example.services.dtos.request.musics.AddMusicToPlayListRequest;
import org.example.services.dtos.request.playlists.*;
import org.example.services.dtos.response.BasePaginationResponse;
import org.example.services.dtos.response.BaseResponse;
import org.example.services.dtos.response.PaginationResponse;
import org.example.services.dtos.response.playlists.GetPlayListDetailResponse;
import org.example.services.dtos.response.playlists.GetPlayListResponse;
import org.example.services.interfaces.PlayListService;

import java.util.List;

@ApplicationScoped
@Controller("playlists")
public class PlayListController {
    @Inject
    private PlayListService playListService;

    @HttpMethod.POST("")
    public BaseResponse<?> createNewPlayList(
            @RequestParameter.RequestBody CreateNewPlayListRequest request,
            @FormFile("file") FileUpload file
    ) {
        this.playListService.createNewPlayList(request, file);
        return new BaseResponse<>(
                true,
                "Create new Play List successfully"
        );
    }

    @HttpMethod.GET("")
    public BasePaginationResponse<GetPlayListResponse> getPlayLists(@RequestParameter.QueryParam GetPlayListsRequest request) {
        var result = this.playListService.getPlayLists(request);
        return new BasePaginationResponse<>(
                true,
                "Get Play Lists successfully",
                result.page,
                result.pageSize,
                result.totalPage,
                result.totalRecords,
                result.currentPageRecords,
                result.data
        );
    }

    @HttpMethod.POST("/delete")
    public BaseResponse<?> deletePlayList(@RequestParameter.QueryParam DeletePlayListRequest request) {
        this.playListService.deletePlayList(request);

        return new BaseResponse<>(
                true,
                "Delete Play List successfully"
        );
    }

    @HttpMethod.POST("/update")
    public BaseResponse<?> updatePlayList(
            @RequestParameter.RequestBody UpdatePlayListRequest request,
            @FormFile("file") FileUpload fileUpload
    ) {
        this.playListService.updatePlayList(request, fileUpload);

        return new BaseResponse<>(
                true,
                "Update Play List successfully"
        );
    }

    @HttpMethod.POST("/musics")
    public BaseResponse<?> addMusicToPlayList(
            @RequestParameter.RequestBody AddMusicToPlayListRequest request) {
        this.playListService.addMusicToPlayList(request);

        return new BaseResponse<>(
                true,
                "Add Music into Play List successfully"
        );
    }

    @HttpMethod.GET("/details")
    public BaseResponse<GetPlayListDetailResponse> getPlayListDetails(
            @RequestParameter.QueryParam GetPlayListDetailRequest request) {
        return new BaseResponse<>(
                true,
                "Get Play List Details successfully",
                this.playListService.getPlayListDetail(request)
        );
    }
}
