package org.example.controllers.implementations;

import com.sun.net.httpserver.HttpExchange;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.example.services.dtos.request.singers.CreateSingerRequest;
import org.example.services.dtos.request.singers.DeleteSingerRequest;
import org.example.services.dtos.request.singers.UpdateSingerRequest;
import org.example.services.dtos.response.BaseResponse;
import org.example.controllers.annotations.retentions.Controller;
import org.example.controllers.annotations.retentions.HttpMethod;
import org.example.controllers.annotations.retentions.RequestParameter;
import org.example.helpers.JsonConverter;
import org.example.services.dtos.request.singers.GetSingerRequest;
import org.example.services.dtos.response.singers.GetSingerResponse;
import org.example.services.interfaces.SingerService;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;

@Controller("singers")
@ApplicationScoped
public class SingerController {
    @Inject
    private SingerService singerService;

    @HttpMethod.POST("")
    public BaseResponse<?> createSinger(@RequestParameter.RequestBody CreateSingerRequest request) {
        this.singerService.createNewSinger(request.name, request.age);
        return new BaseResponse<>(
                true,
                "Create new Singer successfully"
        );
    }

    @HttpMethod.GET("")
    public BaseResponse<GetSingerResponse> getSinger(@RequestParameter.QueryParam GetSingerRequest request) {
        var response = this.singerService.getSinger(request.id);


        return new BaseResponse<>(
            true,
            "Get Singer successfully",
                response
        );
    }

    @HttpMethod.GET("/all")
    public BaseResponse<List<GetSingerResponse>> getSingers() {
        var response = this.singerService.getSingers();

        return new BaseResponse<>(
                true,
                "Get Singer list successfully",
                response
        );
    }

    @HttpMethod.PUT("")
    public BaseResponse<?> updateSinger(@RequestParameter.RequestBody UpdateSingerRequest request) {
        this.singerService.updateSinger(request);

        return new BaseResponse<>(
                true,
                "Update Singer successfully"
        );
    }

    @HttpMethod.DELETE("")
    public BaseResponse<?> deleteSinger(@RequestParameter.QueryParam DeleteSingerRequest request) {
        this.singerService.deleteSinger(request);

        return new BaseResponse<>(
                true,
                "Delete Singer successfully"
        );
    }
}






