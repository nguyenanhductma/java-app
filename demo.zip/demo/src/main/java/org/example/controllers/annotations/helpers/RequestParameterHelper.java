package org.example.controllers.annotations.helpers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class RequestParameterHelper {
    private static final ObjectMapper mapper = new ObjectMapper();

    public static String readRequestBody(HttpExchange exchange) throws IOException {
        return new String(exchange.getRequestBody().readAllBytes());
    }

    public static Map<String, Object> getQueryParams(HttpExchange exchange) {
        String query = exchange.getRequestURI().getQuery();
        return parseQueryString(query);
    }

    public static Map<String, Object> parseQueryString(String query) {
        Map<String, Object> map = new HashMap<>();

        if(query == null || query.isBlank()) {
            return map;
        }

        for(String param : query.split("&")) {
            String[] pair = param.split("=", 2);
            String key = decode(pair[0]);
            String value = pair.length > 1 ? decode(pair[1]) : "";

            if(map.containsKey(key)) {
                Object existing = map.get(key);
                if(existing instanceof List<?>) {
                    ((List<Object>) existing).add(convertValue(value));
                } else {
                    List<Object> list = new ArrayList<>();
                    list.add(existing);
                    list.add(convertValue(value));
                    map.put(key, list);
                }
            } else {
                map.put(key, convertValue(value));
            }
        }

        return map;
    }

    private static String decode(String input) {
        return URLDecoder.decode(input, StandardCharsets.UTF_8);
    }

    private static Object convertValue(String value) {
        if(value == null) {
            return null;
        }

        if (value.startsWith("[") && value.endsWith("]")) {
            try {
                return mapper.readValue(value, List.class);
            } catch (Exception ignored) {}
        }

        if(value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false")) {
            return Boolean.parseBoolean(value);
        }

        try {
            return Integer.parseInt(value);
        } catch (Exception ignore) { }

        try {
            return Long.parseLong(value);
        } catch (Exception ignore) { }

        try {
            return UUID.fromString(value);
        } catch (Exception ignore) { }

        return value;
    }

    public static <T> T mapToObject(Map<String, String> map, Class<T> cls) {
        Map<String, Object> convertedMap = new HashMap<>();

        for (Map.Entry<String, String> entry : map.entrySet()) {
            convertedMap.put(entry.getKey(), convertValue(entry.getValue()));
        }

        return mapper.convertValue(convertedMap, cls);
    }
}
