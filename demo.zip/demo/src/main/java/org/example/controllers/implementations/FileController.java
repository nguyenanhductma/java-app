package org.example.controllers.implementations;

import com.sun.net.httpserver.HttpExchange;
import jakarta.enterprise.context.ApplicationScoped;
import org.example.controllers.annotations.retentions.Controller;
import org.example.controllers.annotations.retentions.HttpMethod;
import org.example.controllers.annotations.retentions.RequestParameter;
import org.example.services.dtos.request.files.GetFileRequest;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Controller("files")
@ApplicationScoped
public class FileController {
    @HttpMethod.GET("")
    public void getFile(
            @RequestParameter.QueryParam GetFileRequest request,
            HttpExchange exchange
    ) {
        try {
            Path path = Paths.get("uploads").resolve(request.fileName);

            if (!Files.exists(path)) {
                return;
            }

            String contentType = Files.probeContentType(path);
            if (contentType == null) {
                contentType = "application/octet-stream";
            }

            byte[] bytes = Files.readAllBytes(path);

            exchange.getResponseHeaders().set("Content-Type", contentType);
            exchange.sendResponseHeaders(200, bytes.length);

            exchange.getResponseBody().write(bytes);
            exchange.getResponseBody().close();

        } catch (Exception e) {
        }
    }
}
