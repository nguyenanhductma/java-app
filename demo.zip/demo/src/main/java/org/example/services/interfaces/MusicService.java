package org.example.services.interfaces;

import org.example.services.dtos.request.musics.CreateNewMusicRequest;
import org.example.services.dtos.request.musics.GetMusicBySingerRequest;
import org.example.services.dtos.request.musics.UpdateMusicRequest;
import org.example.services.dtos.response.musics.GetMusicResponse;

import java.util.List;

public interface MusicService {
    void createMusic(CreateNewMusicRequest request);
    List<GetMusicResponse> getMusicsBySinger(GetMusicBySingerRequest request);
    void updateMusic(UpdateMusicRequest request);
}
