package org.example.services.kafka.events.cores;

public interface EventSubscriber {
    <T extends DomainEvent> void subscribe(
            Class<T> eventClass,
            EventHandler<T> handler
    );
}