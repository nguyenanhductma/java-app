package org.example.services.dtos.request.files;

public class GetFileRequest {
    public String fileName;
}
