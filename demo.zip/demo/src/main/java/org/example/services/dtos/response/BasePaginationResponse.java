package org.example.services.dtos.response;

import java.util.List;

public class BasePaginationResponse<T> {
    public boolean success;
    public String message;
    public int page;
    public int pageSize;
    public int totalPage;
    public int totalRecords;
    public int currentPageRecords;
    public List<T> data;

    public BasePaginationResponse(boolean success, String message, int page, int pageSize, int totalPage, int totalRecords, int currentPageRecords, List<T> data) {
        this.success = success;
        this.message = message;
        this.page = page;
        this.pageSize = pageSize;
        this.totalPage = totalPage;
        this.totalRecords = totalRecords;
        this.currentPageRecords = currentPageRecords;
        this.data = data;
    }
}
