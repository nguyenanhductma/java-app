package org.example.services.dtos.request.singers;

import java.util.UUID;

public class GetSingerRequest {
    public UUID id;
}
