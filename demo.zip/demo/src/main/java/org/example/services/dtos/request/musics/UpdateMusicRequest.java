package org.example.services.dtos.request.musics;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;
import java.util.UUID;

public class UpdateMusicRequest {
    public UUID id;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    public Date releaseDate;
    public String name;
    public String description;
    public UUID singerId;
    public int duration;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public Date getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(Date releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public UUID getSingerId() {
        return singerId;
    }

    public void setSingerId(UUID singerId) {
        this.singerId = singerId;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
}
