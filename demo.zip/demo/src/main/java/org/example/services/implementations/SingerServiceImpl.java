package org.example.services.implementations;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.example.repositories.entities.Singer;
import org.example.repositories.interfaces.SingerRepository;
import org.example.services.dtos.request.singers.DeleteSingerRequest;
import org.example.services.dtos.request.singers.UpdateSingerRequest;
import org.example.services.dtos.response.singers.GetSingerResponse;
import org.example.services.interfaces.SingerService;
import org.example.services.kafka.events.HelloWorldEvent;
import org.example.services.kafka.events.cores.EventPublisher;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@ApplicationScoped
public class SingerServiceImpl implements SingerService {
    @Inject
    private SingerRepository singerRepository;

    @Inject
    private EventPublisher publisher;

    @Override
    public void createNewSinger(String name, int age) {
        this.singerRepository.getTransactionManager().runInTransaction(() -> {
            Singer singer = new Singer();

            singer.setName(name);
            singer.setAge(age);

            this.singerRepository.insert(singer);
        });

    }

    public GetSingerResponse getSinger(UUID uuid) {
        Optional<Singer> singer = this.singerRepository.find("id", uuid, false);

        if (singer.isEmpty()) {
            throw new RuntimeException("Singer not found");
        }

        return new GetSingerResponse(singer.get().getId(), singer.get().getName(), singer.get().getAge());
    }

    public List<GetSingerResponse> getSingers() {
        List<Singer> singers = this.singerRepository
                .getEntityManager()
                .createQuery("SELECT s FROM Singer s", Singer.class)
                .getResultList();

//        HelloWorldEvent event = new HelloWorldEvent();
//        event.setSaySomething("a");
//        publisher.publish(HelloWorldEvent.class, event);

        return singers.stream().map((singer) -> {
                    GetSingerResponse dto = new GetSingerResponse();

                    dto.id = singer.getId();
                    dto.name = singer.getName();
                    dto.age = singer.getAge();

                    return dto;
                })
                .toList();
    }

    @Override
    public void deleteSinger(DeleteSingerRequest request) {
        Optional<Singer> singer = this.singerRepository.find("id", request.id, false);

        if (singer.isEmpty()) {
            throw new RuntimeException("Singer not found");
        }

        this.singerRepository.getTransactionManager().runInTransaction(() -> {
            this.singerRepository.delete(singer.get());
        });
    }

    @Override
    public void updateSinger(UpdateSingerRequest request) {
        Optional<Singer> singer = this.singerRepository.find("id", request.id, false);

        if (singer.isEmpty()) {
            throw new RuntimeException("Singer not found");
        }

        this.singerRepository.getTransactionManager().runInTransaction(() -> {
            singer.get().setName(request.name);
            singer.get().setAge(request.age);

            this.singerRepository.update(singer.get());
        });
    }
}
