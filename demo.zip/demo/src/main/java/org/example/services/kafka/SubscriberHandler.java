package org.example.services.kafka;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.example.services.kafka.events.HelloWorldEvent;
import org.example.services.kafka.subscribers.HelloWorldSubscriber;
import org.example.services.kafka.subscribers.cores.KafkaEventSubscriber;

@ApplicationScoped
public class SubscriberHandler {
    @Inject
    private HelloWorldSubscriber helloWorldSubscriber;

    public void subscribeKafkaEvent(KafkaEventSubscriber subscriber) {
        subscriber.subscribe(
                HelloWorldEvent.class,
                helloWorldSubscriber.onSayingHelloWorld()
        );

        subscriber.start();
    }
}
