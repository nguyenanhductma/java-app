package org.example.services.dtos.request.playlists;

import java.io.File;
import java.util.UUID;

public class UpdatePlayListRequest {
    public UUID id;
    public String name;
    public String description;
    public UUID singerId;
}
