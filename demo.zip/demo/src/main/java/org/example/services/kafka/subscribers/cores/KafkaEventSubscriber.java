package org.example.services.kafka.subscribers.cores;

import org.example.helpers.JsonConverter;
import org.example.services.kafka.events.cores.DomainEvent;
import org.example.services.kafka.events.cores.EventHandler;
import org.example.services.kafka.events.cores.EventRegistry;
import org.example.services.kafka.events.cores.EventSubscriber;

public class KafkaEventSubscriber implements EventSubscriber {

    private final KafkaMultiTopicSubscriber subscriber;

    public KafkaEventSubscriber(KafkaMultiTopicSubscriber subscriber) {
        this.subscriber = subscriber;
    }

    @Override
    public <T extends DomainEvent> void subscribe(
            Class<T> cls,
            EventHandler<T> handler
    ) {
        String topic = EventRegistry.topicOf(cls);

        subscriber.registerHandler(
                topic,
                (key, msg) -> handler.handle(
                        key,
                        JsonConverter.fromJson(msg, cls)
                )
        );
    }

    public void start() {
        new Thread(subscriber).start();
    }
}
