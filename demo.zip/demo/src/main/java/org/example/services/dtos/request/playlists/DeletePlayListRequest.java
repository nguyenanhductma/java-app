package org.example.services.dtos.request.playlists;

import java.util.UUID;

public class DeletePlayListRequest {
    public UUID id;
}
