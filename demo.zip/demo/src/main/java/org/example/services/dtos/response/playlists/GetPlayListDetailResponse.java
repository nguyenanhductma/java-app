package org.example.services.dtos.response.playlists;

import org.example.services.dtos.response.musics.GetMusicResponse;
import org.example.services.dtos.response.singers.GetSingerResponse;

import java.util.List;
import java.util.UUID;

public class GetPlayListDetailResponse {
    public UUID id;
    public String name;
    public String description;
    public String imageUrl;
    public List<GetMusicResponse> musics;
    public GetSingerResponse singer;

    public GetPlayListDetailResponse(UUID id, String name, String description, String imageUrl, List<GetMusicResponse> musics, GetSingerResponse singer) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.imageUrl = imageUrl;
        this.musics = musics;
        this.singer = singer;
    }

    public GetPlayListDetailResponse() {

    }
}
