package org.example.services.dtos.request.singers;

public class CreateSingerRequest {
    public String name;
    public int age;

    public CreateSingerRequest() {
    }

    public CreateSingerRequest(String name, int age) {
        this.name = name;
        this.age = age;
    }
}
