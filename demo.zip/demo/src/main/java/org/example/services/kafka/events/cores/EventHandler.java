package org.example.services.kafka.events.cores;

public interface EventHandler<T> {
    void handle(String key, T event);
}