package org.example.services.dtos.request.singers;

import java.util.UUID;

public class DeleteSingerRequest {
    public UUID id;

    public DeleteSingerRequest() {
    }

    public DeleteSingerRequest(UUID id) {
        this.id = id;
    }
}
