package org.example.services.kafka.events.cores;

public interface EventPublisher {
    <T extends DomainEvent> void publish(
            Class<T> eventClass,
            T event
    );

    <T extends DomainEvent> void publishWithKey(
            Class<T> eventClass,
            String key,
            T event
    );
}