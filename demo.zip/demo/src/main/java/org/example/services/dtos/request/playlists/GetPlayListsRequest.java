package org.example.services.dtos.request.playlists;

public class GetPlayListsRequest {
    public int page;
    public int pageSize;
    public String name;
}
