package org.example.services.dtos.response;

import java.util.List;

public class PaginationResponse<T> {
    public int page;
    public int pageSize;
    public int totalPage;
    public int totalRecords;
    public int currentPageRecords;
    public List<T> data;

    public PaginationResponse(int page, int pageSize, int totalPage, int totalRecords, int currentPageRecords, List<T> data) {
        this.page = page;
        this.pageSize = pageSize;
        this.totalPage = totalPage;
        this.totalRecords = totalRecords;
        this.currentPageRecords = currentPageRecords;
        this.data = data;
    }
}
