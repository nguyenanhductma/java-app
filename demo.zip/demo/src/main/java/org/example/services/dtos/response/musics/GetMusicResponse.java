package org.example.services.dtos.response.musics;

import java.util.Date;
import java.util.UUID;

public class GetMusicResponse {
    public UUID id;
    public Date releaseDate;
    public String name;
    public String description;
    public int duration;

    public GetMusicResponse() {
    }

    public GetMusicResponse(UUID id, Date releaseDate, String name, String description, int duration) {
        this.id = id;
        this.releaseDate = releaseDate;
        this.name = name;
        this.description = description;
        this.duration = duration;
    }
}
