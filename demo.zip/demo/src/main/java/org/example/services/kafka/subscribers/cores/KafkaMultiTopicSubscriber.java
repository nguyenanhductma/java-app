package org.example.services.kafka.subscribers.cores;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.function.BiConsumer;

public class KafkaMultiTopicSubscriber implements Runnable {

    private final KafkaConsumer<String, String> consumer;
    private final Map<String, BiConsumer<String, String>> handlers = new HashMap<>();
    private volatile boolean running = true;

    public KafkaMultiTopicSubscriber(String bootstrap,
                                     String groupId,
                                     Collection<String> topics) {

        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrap);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        consumer = new KafkaConsumer<>(props);
        consumer.subscribe(topics);
    }

    public void registerHandler(String topic,
                                BiConsumer<String, String> handler) {
        handlers.put(topic, handler);
    }

//    public void start() {
//        while (true) {
//            ConsumerRecords<String, String> records =
//                    consumer.poll(Duration.ofMillis(500));
//
//            for (ConsumerRecord<String, String> r : records) {
//                handlers.get(r.topic()).accept(r.key(), r.value());
//            }
//        }
//    }

    @Override
    public void run() {
        try {
            while (running) {
                ConsumerRecords<String, String> records =
                        consumer.poll(Duration.ofMillis(500));

                for (ConsumerRecord<String, String> r : records) {
                    BiConsumer<String, String> handler =
                            handlers.get(r.topic());

                    if (handler != null) {
                        handler.accept(r.key(), r.value());
                    } else {
                        System.err.println(
                                "No handler for topic: " + r.topic()
                        );
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            consumer.close();
        }
    }
}