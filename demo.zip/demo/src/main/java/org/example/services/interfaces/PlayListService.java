package org.example.services.interfaces;

import org.example.controllers.annotations.helpers.FileUpload;
import org.example.services.dtos.request.musics.AddMusicToPlayListRequest;
import org.example.services.dtos.request.playlists.*;
import org.example.services.dtos.response.PaginationResponse;
import org.example.services.dtos.response.playlists.GetPlayListDetailResponse;
import org.example.services.dtos.response.playlists.GetPlayListResponse;

import java.util.List;

public interface PlayListService {
    void createNewPlayList(CreateNewPlayListRequest request, FileUpload fileUpload);
    PaginationResponse<GetPlayListResponse> getPlayLists(GetPlayListsRequest request);
    void deletePlayList(DeletePlayListRequest request);
    void updatePlayList(UpdatePlayListRequest request, FileUpload fileUpload);
    void addMusicToPlayList(AddMusicToPlayListRequest request);
    GetPlayListDetailResponse getPlayListDetail(GetPlayListDetailRequest request);
}
