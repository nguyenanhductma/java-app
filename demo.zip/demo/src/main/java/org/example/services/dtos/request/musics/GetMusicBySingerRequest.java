package org.example.services.dtos.request.musics;

import java.util.UUID;

public class GetMusicBySingerRequest {
    public UUID singerId;

    public GetMusicBySingerRequest(UUID singerId) {
        this.singerId = singerId;
    }

    public GetMusicBySingerRequest() {
    }
}
