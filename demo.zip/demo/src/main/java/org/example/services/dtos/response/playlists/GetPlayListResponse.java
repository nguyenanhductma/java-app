package org.example.services.dtos.response.playlists;

import java.io.File;
import java.util.UUID;

public class GetPlayListResponse {
    public UUID id;
    public String name;
    public String description;
    public String imageUrl;
    public UUID singerId;

    public GetPlayListResponse() {
    }

    public GetPlayListResponse(UUID id, String name, String description, String imageUrl, UUID singerId) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.imageUrl = imageUrl;
        this.singerId = singerId;
    }
}
