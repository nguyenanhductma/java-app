package org.example.services.dtos.request.musics;

import java.util.List;
import java.util.UUID;

public class AddMusicToPlayListRequest {
    public UUID id;
    public List<UUID> musicIds;
}
