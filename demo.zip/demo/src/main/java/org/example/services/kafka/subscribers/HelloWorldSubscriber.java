package org.example.services.kafka.subscribers;

import jakarta.enterprise.context.ApplicationScoped;
import org.example.services.kafka.events.HelloWorldEvent;
import org.example.services.kafka.events.cores.EventHandler;

@ApplicationScoped
public class HelloWorldSubscriber {
    public EventHandler<HelloWorldEvent> onSayingHelloWorld() {
        return (key, event) -> System.out.println("Receive data from event: " + event.saySomething);
    }
}
