package org.example.services.dtos.response.singers;

import java.util.UUID;

public class GetSingerResponse {
    public UUID id;
    public String name;
    public int age;
    public String avatarUrl;

    public GetSingerResponse(UUID id, String name, int age, String avatarUrl) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.avatarUrl = avatarUrl;
    }

    public GetSingerResponse() {
    }

    public GetSingerResponse(UUID id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }
}
