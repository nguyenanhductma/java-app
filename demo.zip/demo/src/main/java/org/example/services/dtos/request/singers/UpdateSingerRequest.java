package org.example.services.dtos.request.singers;

import java.util.UUID;

public class UpdateSingerRequest {
    public UUID id;
    public String name;
    public int age;

    public UpdateSingerRequest(UUID id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public UpdateSingerRequest(UUID id) {
        this.id = id;
    }
}
