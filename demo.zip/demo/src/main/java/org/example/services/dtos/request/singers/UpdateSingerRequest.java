package org.example.services.dtos.request.singers;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.UUID;

public class UpdateSingerRequest {
    public UUID id;
    public String name;
    public int age;

    @JsonCreator
    public UpdateSingerRequest(
            @JsonProperty("id") UUID id,
            @JsonProperty("name") String name,
            @JsonProperty("age") int age
    ) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public UpdateSingerRequest(UUID id) {
        this.id = id;
    }
}
