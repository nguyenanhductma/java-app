package org.example.services.kafka.publishers.cores;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.example.services.kafka.events.cores.EventRegistry;

import java.util.HashMap;
import java.util.Map;

@ApplicationScoped
public class KafkaPublisherManager {

    private static final Map<String, KafkaPublisher> publishers = new HashMap<>();

    public KafkaPublisherManager() {
    }

    public void registerKafkaPublisherManager(String bootstrap) {
        EventRegistry.allTopics().forEach(topic ->
                publishers.put(topic, new KafkaPublisher(bootstrap, topic))
        );
    }

    public KafkaPublisher get(String topic) {
        return publishers.get(topic);
    }
}