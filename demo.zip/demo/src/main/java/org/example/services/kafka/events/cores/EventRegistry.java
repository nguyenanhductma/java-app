package org.example.services.kafka.events.cores;

import org.example.services.kafka.events.HelloWorldEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class EventRegistry {
    private static final Map<Class<? extends DomainEvent>, String> TOPICS =
            new HashMap<>();

    static {
        register(HelloWorldEvent.class);
    }

    private static void register(Class<? extends DomainEvent> cls) {
        EventTopic annotation = cls.getAnnotation(EventTopic.class);
        if (annotation == null) {
            throw new IllegalStateException(
                    "Missing @EventTopic on " + cls.getName()
            );
        }
        TOPICS.put(cls, annotation.value());
    }

    public static String topicOf(Class<? extends DomainEvent> cls) {
        return TOPICS.get(cls);
    }

    public static Set<String> allTopics() {
        return Set.copyOf(TOPICS.values());
    }

    private EventRegistry() {}
}
