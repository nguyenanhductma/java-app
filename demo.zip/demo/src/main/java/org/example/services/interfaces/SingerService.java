package org.example.services.interfaces;

import org.example.services.dtos.request.singers.DeleteSingerRequest;
import org.example.services.dtos.request.singers.UpdateSingerRequest;
import org.example.services.dtos.response.singers.GetSingerResponse;

import java.util.List;
import java.util.UUID;

public interface SingerService {
    void createNewSinger(String name, int age);
    GetSingerResponse getSinger(UUID uuid);
    List<GetSingerResponse> getSingers();
    void deleteSinger(DeleteSingerRequest request);
    void updateSinger(UpdateSingerRequest request);
}
