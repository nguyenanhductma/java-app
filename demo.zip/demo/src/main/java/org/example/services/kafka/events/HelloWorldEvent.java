package org.example.services.kafka.events;

import org.example.services.kafka.events.cores.DomainEvent;
import org.example.services.kafka.events.cores.EventTopic;

@EventTopic("hello-world")
public class HelloWorldEvent implements DomainEvent {
    public String saySomething;

    public HelloWorldEvent(String saySomething) {
        this.saySomething = saySomething;
    }

    public String getSaySomething() {
        return saySomething;
    }

    public void setSaySomething(String saySomething) {
        this.saySomething = saySomething;
    }

    public HelloWorldEvent() {
    }
}
