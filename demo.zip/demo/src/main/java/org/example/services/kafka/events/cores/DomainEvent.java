package org.example.services.kafka.events.cores;

public interface DomainEvent {
}
