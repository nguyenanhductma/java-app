package org.example.services.implementations;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.apache.commons.lang3.StringUtils;
import org.example.controllers.annotations.helpers.FileUpload;
import org.example.repositories.entities.Music;
import org.example.repositories.entities.PlayList;
import org.example.repositories.entities.Singer;
import org.example.repositories.interfaces.MusicRepository;
import org.example.repositories.interfaces.PlayListRepository;
import org.example.repositories.interfaces.SingerRepository;
import org.example.services.dtos.request.musics.AddMusicToPlayListRequest;
import org.example.services.dtos.request.playlists.*;
import org.example.services.dtos.response.PaginationResponse;
import org.example.services.dtos.response.musics.GetMusicResponse;
import org.example.services.dtos.response.playlists.GetPlayListDetailResponse;
import org.example.services.dtos.response.playlists.GetPlayListResponse;
import org.example.services.dtos.response.singers.GetSingerResponse;
import org.example.services.helpers.FileHelper;
import org.example.services.interfaces.PlayListService;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@ApplicationScoped
public class PlayListServiceImpl implements PlayListService {
    @Inject
    private PlayListRepository playListRepository;

    @Inject
    private SingerRepository singerRepository;

    @Inject
    private MusicRepository musicRepository;

    @Override
    public void createNewPlayList(CreateNewPlayListRequest request, FileUpload fileUpload) {
        Optional<Singer> singer = this.singerRepository.find("id", request.singerId, false);

        if (singer.isEmpty()) {
            throw new RuntimeException("Singer not found");
        }

        this.playListRepository.getTransactionManager().runInTransaction(() -> {
            PlayList playList = new PlayList();

            if (fileUpload != null) {
                Path path = FileHelper.saveFile(fileUpload);
                playList.setImageUrl(path.getFileName().toString());
            }


            playList.setName(request.name);
            playList.setDescription(request.description);
            playList.setSinger(singer.get());

            this.playListRepository.insert(playList);

            if (request.musicIds.isEmpty()) {
                return;
            }

            for (UUID musicId : request.musicIds) {
                Optional<Music> music = this.musicRepository.find("id", musicId, false);

                if (music.isEmpty()) {
                    continue;
                }

                music.get().setPlayList(playList);
                this.musicRepository.update(music.get());
            }
        });
    }

    @Override
    public PaginationResponse<GetPlayListResponse> getPlayLists(GetPlayListsRequest request) {
        if(StringUtils.isBlank(request.name)) {
            request.name = StringUtils.trimToEmpty(request.name);
        }

        List<PlayList> playLists = this.playListRepository.getEntityManager()
                .createQuery("select p from PlayList p where p.deletedTime is null" +
                        " AND LOWER(p.name) LIKE LOWER(:name) ORDER BY p.createdTime desc", PlayList.class)
                .setFirstResult((request.page - 1) * request.pageSize)
                .setMaxResults(request.pageSize)
                .setParameter("name", "%" + request.name + "%")
                .getResultList();

        Long totalRecords = this.playListRepository.getEntityManager()
                .createQuery(
                        "SELECT COUNT(p) FROM PlayList p WHERE p.deletedTime IS NULL",
                        Long.class
                )
                .getSingleResult();

        List<GetPlayListResponse> data = playLists.stream()
                .map(p -> {
                    GetPlayListResponse dto = new GetPlayListResponse();

                    dto.id = p.getId();
                    dto.name = p.getName();
                    dto.description = p.getDescription();
                    dto.imageUrl = p.getImageUrl();
                    dto.singerId = p.getSinger().getId();

                    return dto;
                })
                .toList();
        return new PaginationResponse<>(
                request.page,
                request.pageSize,
                (int) Math.ceil((double) totalRecords / request.pageSize),
                Math.toIntExact(totalRecords),
                data.size(),
                data
        );
    }

    @Override
    public void deletePlayList(DeletePlayListRequest request) {
        Optional<PlayList> playList = this.playListRepository.find("id", request.id, false);

        if (playList.isEmpty()) {
            throw new RuntimeException("PlayList not found");
        }

        this.playListRepository.getTransactionManager().runInTransaction(() -> {
            this.playListRepository.delete(playList.get());
        });
    }

    @Override
    public void updatePlayList(UpdatePlayListRequest request, FileUpload fileUpload) {
        Optional<PlayList> playList = this.playListRepository.find("id", request.id, false);

        if (playList.isEmpty()) {
            throw new RuntimeException("PlayList not found");
        }

        Optional<Singer> singer = this.singerRepository.find("id", request.singerId, false);

        if (singer.isEmpty()) {
            throw new RuntimeException("Singer not found");
        }

        this.playListRepository.getTransactionManager().runInTransaction(() -> {
            if (fileUpload != null) {
                Path path = FileHelper.saveFile(fileUpload);
                playList.get().setImageUrl(path.getFileName().toString());
            }

            playList.get().setName(request.name);
            playList.get().setDescription(request.description);
            playList.get().setSinger(singer.get());

            this.playListRepository.update(playList.get());
        });
    }

    public void addMusicToPlayList(AddMusicToPlayListRequest request) {
        Optional<PlayList> playList = this.playListRepository.find("id", request.id, false);

        if (playList.isEmpty()) {
            return;
        }

        this.musicRepository.getTransactionManager().runInTransaction(() -> {
            for (UUID musicId : request.musicIds) {
                Optional<Music> music = this.musicRepository.find("id", musicId, false);

                if (music.isEmpty()) {
                    continue;
                }

                music.get().setPlayList(playList.get());

                this.musicRepository.update(music.get());
            }
        });
    }

    public GetPlayListDetailResponse getPlayListDetail(GetPlayListDetailRequest request) {
        Optional<PlayList> playList = this.playListRepository.find("id", request.id, false);

        if (playList.isEmpty()) {
            return new GetPlayListDetailResponse();
        }

        Optional<Singer> singer = this.singerRepository.find("id", playList.get().getSinger().getId(), false);

        if (singer.isEmpty()) {
            return new GetPlayListDetailResponse();
        }

        List<Music> musics = this.musicRepository.getEntityManager().createQuery("SELECT m FROM Music m where " +
                        "m.deletedTime IS NULL AND m.playList.id = :playListId", Music.class)
                .setParameter("playListId", playList.get().getId())
                .getResultList();

        return new GetPlayListDetailResponse(
                playList.get().getId(),
                playList.get().getName(),
                playList.get().getDescription(),
                playList.get().getImageUrl(),
                new ArrayList<>(
                        musics.stream().map(m -> new GetMusicResponse(
                                        m.getId(),
                                        m.getReleaseDate(),
                                        m.getName(),
                                        m.getDescription(),
                                        m.getDuration()
                                ))
                                .collect(Collectors.toList())),
                new GetSingerResponse(
                        singer.get().getId(),
                        singer.get().getName(),
                        singer.get().getAge(),
                        singer.get().getAvatarUrl()
                )
        );
    }
}
