package org.example.services.helpers;

import org.example.controllers.annotations.helpers.FileUpload;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class FileHelper {
    public static Path saveFile(FileUpload fileUpload) {
        try {
            Path uploadDir = Paths.get("uploads");

            if (!Files.exists(uploadDir)) {
                Files.createDirectories(uploadDir);
            }

            Path filePath = uploadDir.resolve(fileUpload.fileName);

            Files.write(filePath, fileUpload.bytes, StandardOpenOption.CREATE);

            return filePath;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
