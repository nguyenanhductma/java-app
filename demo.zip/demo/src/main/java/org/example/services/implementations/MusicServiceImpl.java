package org.example.services.implementations;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.example.repositories.entities.Music;
import org.example.repositories.entities.Singer;
import org.example.repositories.interfaces.MusicRepository;
import org.example.repositories.interfaces.SingerRepository;
import org.example.services.dtos.request.musics.CreateNewMusicRequest;
import org.example.services.dtos.request.musics.GetMusicBySingerRequest;
import org.example.services.dtos.request.musics.UpdateMusicRequest;
import org.example.services.dtos.response.musics.GetMusicResponse;
import org.example.services.interfaces.MusicService;

import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class MusicServiceImpl implements MusicService {
    @Inject
    private MusicRepository musicRepository;

    @Inject
    private SingerRepository singerRepository;

    @Override
    public void createMusic(CreateNewMusicRequest request) {
        Optional<Singer> singer = singerRepository.find("id", request.singerId, false);

        if (singer.isEmpty()) {
            throw new RuntimeException("Singer not found");
        }

        this.musicRepository.getTransactionManager().runInTransaction(() -> {
            Music music = new Music();

            music.setName(request.name);
            music.setDescription(request.description);
            music.setReleaseDate(request.releaseDate);
            music.setDuration(request.duration);
            music.setSinger(singer.get());

            this.musicRepository.insert(music);
        });
    }

    @Override
    public void updateMusic(UpdateMusicRequest request) {
        Optional<Singer> singer = singerRepository.find("id", request.singerId, false);

        if (singer.isEmpty()) {
            throw new RuntimeException("Singer not found");
        }

        Optional<Music> music = musicRepository.find("id", request.id, false);

        if(music.isEmpty()) {
            throw new RuntimeException("Music not found");
        }

        this.musicRepository.getTransactionManager().runInTransaction(() -> {
            music.get().setName(request.name);
            music.get().setDescription(request.description);
            music.get().setReleaseDate(request.releaseDate);
            music.get().setDuration(request.duration);
            music.get().setSinger(singer.get());

            this.musicRepository.update(music.get());
        });
    }

    @Override
    public List<GetMusicResponse> getMusicsBySinger(GetMusicBySingerRequest request) {
        Optional<Singer> singer = this.singerRepository.find("id", request.singerId, false);

        if (singer.isEmpty()) {
            throw new RuntimeException("Singer not found");
        }

        List<Music> musics = this.musicRepository
                .getEntityManager()
                .createQuery("SELECT m FROM Music m WHERE m.deletedTime is NULL AND m.singer.id = :singerId", Music.class)
                .setParameter("singerId", singer.get().getId())
                .getResultList();

        return musics.stream().map((music) -> {
            GetMusicResponse dto = new GetMusicResponse();

            dto.id = music.getId();
            dto.name = music.getName();
            dto.description = music.getDescription();
            dto.releaseDate = music.getReleaseDate();
            dto.duration = music.getDuration();

            return dto;
        }).toList();
    }
}
