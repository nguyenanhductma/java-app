package org.example.services.dtos.request.musics;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;
import java.util.UUID;

public class CreateNewMusicRequest {
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    public Date releaseDate;
    public String name;
    public String description;
    public UUID singerId;
    public int duration;

    public CreateNewMusicRequest() {
    }

    public CreateNewMusicRequest(Date releaseDate, String name, String description, UUID singerId, int duration) {
        this.releaseDate = releaseDate;
        this.name = name;
        this.description = description;
        this.singerId = singerId;
        this.duration = duration;
    }
}
