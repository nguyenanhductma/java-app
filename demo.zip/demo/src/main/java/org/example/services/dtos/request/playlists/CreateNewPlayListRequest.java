package org.example.services.dtos.request.playlists;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class CreateNewPlayListRequest {
    public String name;
    public String description;
    public UUID singerId;
    public List<UUID> musicIds = new ArrayList<>();

    public CreateNewPlayListRequest(String name, String description, UUID singerId, List<UUID> musicIds) {
        this.name = name;
        this.description = description;
        this.singerId = singerId;
        this.musicIds = musicIds;
    }

    public CreateNewPlayListRequest() {
    }
}
