package org.example.services.dtos.request.playlists;

import java.util.UUID;

public class GetPlayListDetailRequest {
    public UUID id;
}
