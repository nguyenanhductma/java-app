package org.example.services.kafka.publishers.cores;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.example.helpers.JsonConverter;
import org.example.services.kafka.events.cores.DomainEvent;
import org.example.services.kafka.events.cores.EventPublisher;
import org.example.services.kafka.events.cores.EventRegistry;

@ApplicationScoped
public class KafkaEventPublisher implements EventPublisher {

    @Inject
    private KafkaPublisherManager manager;

    public KafkaEventPublisher() {
    }

    @Override
    public <T extends DomainEvent> void publish(
            Class<T> cls,
            T event
    ) {
        String topic = EventRegistry.topicOf(cls);
        manager.get(topic).publish(cls.getName(), JsonConverter.toJson(event));
    }

    @Override
    public <T extends DomainEvent> void publishWithKey(Class<T> eventClass, String key, T event) {
        String topic = EventRegistry.topicOf(eventClass);
        manager.get(topic).publish(key, JsonConverter.toJson(event));
    }
}